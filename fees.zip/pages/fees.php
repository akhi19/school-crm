<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">

    <?php require_once 'header.php'; ?>
    <?php require_once 'navigation.php'; ?>
    <?php 
        $allClassList = getMultipleRecord('class');
    ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Search Student
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"><a href="#">fees</a></li>

            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12 col-md-12">

                    <div class="box">
                        <div class="box-header">

                            <div class="col-md-8 pl0">
                                <div class="pull-left">
                                    <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-primary" data-toggle="modal" data-target="#addFees">
                                            <i class="fa fa-plus"></i> Add New Student for fees</a>
                                    <?php } ?>
                                </div>

                            </div>
                            <div class="col-md-4">

                            </div>

                            <form action="#" method="get"  >
                                <div class="row">
                                    <div class="col-md-8 ">
                                        <div class="row mt-25">
                                            <div class="col-md-3">
                                                <select name="studSearchOptions" id="studSearchOptions" class="form-control" >
                                                    <option value="0">Search By</option>
                                                    <option value="1">Aadhar No.</option>
                                                    <option value="2">GR No.</option>
                                                    <option value="3">Fathers Mobile No.</option>
                                                    <option value="4">Mothers Mobile No.</option>
                                                </select>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                            </form>
                        </div>

                        <!-- /.box-header -->
                        <div class="box-body">
                        <form id="aadhar_form" class="student_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="text">Aadhar Card No:</label>
                                        <input type="text" class="form-control" id="aadhar_no"
                                            name="aadhar_no" placeholder="Enter Aadhar Card No">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                    <button type="button"  onclick="getStudentByAadharNo()" class="btn btn-primary
                                    btn-flat submit-trigger">Search Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                            </div>
                        </form>
                        <form id="gr_form" class="student_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="text">GR No:</label>
                                        <input type="text" class="form-control" id="gr_no"
                                               name="gr_no" placeholder="Enter GR No">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                    <button type="button"  onclick="getStudentByGRNo()" class="btn btn-primary
                                    btn-flat submit-trigger">Search Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                            </div>
                        </form> 
                        <form id="father_mob_form" class="student_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="text">Father Mobile:</label>
                                        <input type="text" class="form-control" id="father_mobile"
                                           name="father_mobile" placeholder="Enter Father Mobile">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                    <button type="button"  onclick="getStudentByFatherMobile()" class="btn btn-primary
                                    btn-flat submit-trigger">Search Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                            </div>
                        </form>
                        <form id="mother_mob_form" class="student_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="text">Mother Mobile:</label>
                                        <input type="text" class="form-control" id="mother_mobile"
                                                name="mother_mobile" placeholder="Enter Mother Mobile">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                    <button type="button"  onclick="getStudentByMotherMobile()" class="btn btn-primary
                                    btn-flat submit-trigger">Search Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
                            </div>
                        </form>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                    <div id="studentList"></div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <div id="addFees" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Fees</h4>
                </div>
                <div class="modal-body">
                    <div id="response"></div>
                    <form id="add_fees_form" class="student_form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">GR No:</label>
                                            <input type="text" class="form-control" id="add_fees_gr_no"
                                                   name="add_fees_gr_no" placeholder="Enter GR No">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Outstanding Fees:</label>
                                            <input type="text"  class="form-control" id="outstanding_fees" name="outstanding_fees" placeholder="Enter outstanding fees" >
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">First Name:</label>
                                            <input type="text" class="form-control" id="first_name"
                                                name="first_name" placeholder="Enter First Name">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Last Name:</label>
                                            <input type="text" class="form-control" id="last_name"
                                                name="last_name" placeholder="Enter Last Name">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="text">Present Class:</label>
                                            <select class="form-control" id="present_class" name="present_class">
                                            <option value="0">Select Class</option>
                                                <?php foreach ($allClassList as $row){ ?>
                                                    <option value="<?php echo $row['name'];?>"><?php echo $row['name']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="text">Academic Year:</label>
                                            <input type="text" class="form-control" id="academic_year"
                                                name="academic_year" placeholder="Enter academic year">
                                         </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="text">Fees from month:</label>
                                            <select class="form-control" id="fees_month" name="fees_month">
                                                    <option value="0">Please Select</option>
                                                    <option value="7"> January </option>
                                                    <option value="8"> February</option>
                                                    <option value="9"> March </option>
                                                    <option value="10"> April </option>
                                                    <option value="11"> May </option>
                                                    <option value="0"> June </option>
                                                    <option value="1"> July </option>
                                                    <option value="2"> August </option>
                                                    <option value="3"> September </option>
                                                    <option value="4"> October </option>
                                                    <option value="5"> November </option>
                                                    <option value="6"> December </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button"  onclick="addFeesForStudent()" class="btn btn-primary
                                    btn-flat submit-trigger">Add Fees</button>
                                    <button type="button" style="display: none;" class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
                                </div>
                            </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

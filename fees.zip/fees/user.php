<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">
	
	<?php require_once 'header.php'; ?>
	<?php require_once 'navigation.php'; ?>
	
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				User
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active"><a href="#">User</a></li>
			
			</ol>
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-xs-12">
					
					<div class="box">
						<div class="box-header">
							<h6 class="page-header">
								
								<a id="" class="btn btn-primary" data-toggle="modal" data-target="#addUser">
									+ Add New User</a>
									
									<a href="javascript:void(0)" class="btn btn-info userMessage" >
                                            <i class="fa fa-envelope"></i> Send Message</a>

                                    <a href="javascript:void(0)" class="btn btn-warning" data-toggle="modal"
                                       data-target="#bulkUpload">
                                    <i class="fa fa-upload"></i> Bulk Upload</a>

                                    <a href="/sample.csv" class="btn btn-danger" >
                                    <i class="fa fa-file"></i> Sample CSV</a>
									
									<a href="/user-report" class="btn btn-success" >
                                            <i class="fa fa-file"></i> Export CSV</a>
							</h6>
						</div>
						
						<!-- /.box-header -->
						<div class="box-body">
                            <div id="error-user"></div>
							<table id="class-table" class="table table-bordered table-striped">
								<thead>
								<tr>
								    <th><input type="checkbox" id="checkAlluser"></th>
									<th>Id</th>
									<th>Name</th>
									<th>Email</th>
                                    <th>Active</th>
                                    <th>User Type</th>
									<th>Created Date</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php
									$allUserList = getMultipleRecord('user');
								?>
								<?php if(!empty($allUserList)) { ?>
									<?php $i = 0; foreach($allUserList as $row) { $i++; ?>
										<tr>
										    <td> <input type="checkbox" name="user_message" value="<?php echo
                                                $row['id']; ?>"
                                                        class="user_message"> </td>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['name']; ?> </td>
											<td><?php echo $row['email']; ?> </td>
                                            <td>

                                                <label class="switch">
                                                    <input class="activeUser checkUser" value="<?php echo $row['id']
			                                            ."-".$row['active']; ?>"
                                                           type="checkbox"  <?php echo !empty($row['active'] == 1) ? 'checked' : NULL; ?>>
                                                    <span class="slider"></span>
                                                </label>
                                            
                                            </td>
                                            <td><?php echo ucfirst($row['user_type']); ?></td>
											<td><?php echo $row['created_at']; ?></td>
											<td>
												<a href="javascript:void(0)" id="<?php echo $row['id']; ?>"
												   class="btn btn-warning btn-xs mrg" data-placement="top"
												   data-toggle="modal" data-target="#editUser"
												   data-original-title="Edit"><i class="fa fa-edit"></i></a>
										        <?php if( $_SESSION['sessUser'] == 'admin') { ?>
												    <a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>"
												   class="btn btn-danger btn-xs mrg delete_user"
												   data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
											    <?php } ?>
											</td>
										</tr>
									<?php } ?>
								<?php } ?>
								
								
								</tbody>
								<tfoot>
								
								</tfoot>
							</table>
						</div>
						<!-- /.box-body -->
					</div>
					<!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	<!-- modal class start --->
	
	<!-- Modal -->
	<div id="addUser" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add User</h4>
				</div>
				<div class="modal-body">
					<div id="response"></div>
					<form id="user_form" class="user_form">
						<div class="row">
							<div class="col-md-12">
							    
							    <div class="form-group">
									<label for="text">User Type:</label>
									<select class="form-control" id="add_usertype" name="add_usertype">
                                        <option value="">Please Select</option>
                                        <option value="admin">Admin</option>
                                        <option value="user">User</option> 
                                      </select>

								</div>
							    
								<div class="form-group">
									<label for="text">Name:</label>
									<input type="text" class="form-control" id="add_user" name="add_user"
									       placeholder="Enter Name">
								</div>
								
								<div class="form-group">
									<label for="text">Email:</label>
									<input type="text" class="form-control" id="add_email" name="add_email"
									       placeholder="Enter Email">
								</div>

                                <div class="form-group">
                                    <label for="text">Mobile:</label>
                                    <input type="text" class="form-control" id="add_mobile" name="add_mobile"
                                           placeholder="Enter Mobile">
                                </div>
								
									<div class="form-group">
									<label for="text">Uesrname:</label>
									<input type="text" class="form-control" id="add_username" name="add_username"
									       placeholder="Enter Username">
								</div>
								
								<div class="form-group">
									<label for="text">Password:</label>
									<input type="password" class="form-control" id="add_password" name="add_password"
									       placeholder="Enter Password">
								</div>

                                <div class="form-group">
                                    <label for="text">Confirm Password:</label>
                                    <input type="password" class="form-control" id="add_cpassword" name="add_cpassword"
                                           placeholder="Enter Password">
                                </div>
                                
                                <div id="password_error"><p style = "color: #9f191f;display:none">Password doesnt
                                        match!</p></div>
							
								
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<button type="button"  onclick="addAcademyUser()" class="btn btn-primary
									btn-flat submit-trigger">Add User</button>
									<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
								
								</div>
							</div>
						
						</div>
					
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal class end --->
	
	
	<!-- modal edit class start --->
	
	<!-- Modal -->
	<div id="editUser" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Edit User</h4>
				</div>
				<div class="modal-body">
					<div id="update-response"></div>
					<div id="user_data"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal edit class end --->
	
	<!-- modal delete class start -->
	
	<!-- modal box for delte confirmation start --->
	<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Confirm</h4>
				</div>
				<div class="modal-body">
					<p><strong>Do you really want to delete this record ?</strong></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- end -->
	<!-- modal box for delte confirmation end ---->
	
	<!-- modal delete class end --->

    <!-- Modal -->
    <div id="userMessage" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Send Message : <?php echo date("l jS \of F Y "); ?></h4>
                </div>
                <div class="modal-body">
                    <div id="message-response"></div>
                    <div id="message_data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal send message end --->



    <!-- Modal bulk upload start -->
    <div id="bulkUpload" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Bulk Upload</h4>
                </div>
                <div class="modal-body">
                    <div id="response_csv"></div>
                    <form id="frmCSVImport" class="frmCSVImport">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="text">File:</label>
                                    <input type="file" name="fileToUpload" id="fileToUpload">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="button"  onclick="bulkUploadCsv()" class="btn btn-primary
                                    btn-flat submit-trigger">Upload</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                                </div>
                            </div>

                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal bulk upload end --->
	
	<?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">

    <?php require_once 'header.php'; ?>
    <?php require_once 'navigation.php'; ?>
    <?php
		$allClassList = getMultipleRecord('class');
    $allSectionList =$allRouteList= array();
    if(isset($_GET['cid']) && $_GET['cid']>0){
        $allSectionList = getMultipleRecord('section',array('class_id'=>$_GET['cid']));
    }
		$allBusList = getMultipleRecord('bus_number');
    if(isset($_GET['bid']) && $_GET['bid']>0){
        $allRouteList = getMultipleRecord('bus_route',array('busno_id'=>$_GET['bid']));
    }
		
		$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
		if ($page <= 0) $page = 1;
		
		$per_page = 10; // Set how many records do you want to display per page.
		
		$startpoint = ($page * $per_page) - $per_page;
		

		$empty = "";
        $query = getMessageList(@$_GET['cid'],@$_GET['sid'], @$_GET['bid'], @$_GET['rid']);
        $statement = "`message` WHERE {$query}  ORDER BY `id` DESC ";
        $allMessageList = pagingQuery($statement,$startpoint,$per_page);
        $recordCount = count($allMessageList);
		if(isset($_GET['cid']) !="" || isset($_GET['sid']) !="" || isset($_GET['bid']) !="" || isset($_GET['rid']) !="") {


			if(empty($allMessageList)) {
				$empty = 'There are no results matching your searching criteria.';
			}
			
		} else {
            $empty = 'There are currently no records.';
		}
    $getq = '';
    if(isset($_GET['cid'])&!empty($_GET)){
        if(isset($_GET['page'])){unset($_GET['page']);}
        $getq = "?".http_build_query($_GET);
    }
	?>

	
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				Messages
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active"><a href="#">Message</a></li>
			
			</ol>
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-xs-12">
					
					<div class="box">
					<div class="box-header">
							 
								
                                <div class="col-md-2 pl0">
                                   <a href="/message-report<?= $getq;?>" class="btn btn-success" download>Export CSV</a>
                                   
                                </div>
                                <div class="col-md-10">
                                    <div class="pull-right">
                                            <div class="col-md-3">
                                                <select name="filtermessageclass" id="filtermessageclass" class="form-control">
                                                    <option value="0">Select Class</option>
	
	                                                <?php foreach ($allClassList as $row){ ?>
                                                        <option <?php if(@$_GET['cid'] == $row['id']) { echo "selected"; }
                                                        ?>
                                                                value="<?php
                                                            echo $row['id'];
                                                        ?>"><?php
                                                                echo
                                                        $row['name']; ?></option>
	                                                <?php } ?>
    
                                                </select>
                                            </div>

                                        <div class="col-md-3">
                                            <select name="filtermessagesection" id="filtermessagesection" class="form-control">
                                                <option value="0">Select Division</option>
	
	                                            <?php foreach ($allSectionList as $row){ ?>
                                                    <option <?php if( @$_GET['sid'] == $row['id']) { echo "selected"; }
                                                    ?>  value="<?php echo $row['id']; ?>"><?php echo
                                                        $row['name']; ?></option>
	                                            <?php } ?>

                                            </select>
                                        </div>

                                        <div class="col-md-3">
                                            <select name="filtermessageBusno" id="filtermessageBusno" class="form-control">
                                                <option value="0">Select Bus No</option>
			
			                                    <?php foreach ($allBusList as $row){ ?>
                                                    <option <?php if( @$_GET['bid'] == $row['id']) { echo "selected"; }
				                                    ?>  value="<?php echo $row['id']; ?>"><?php echo
					                                    $row['name']; ?></option>
			                                    <?php } ?>

                                            </select>
                                        </div>

                                        <div class="col-md-3">
                                            <select name="filtermessageBusroute" id="filtermessageBusroute" class="form-control">
                                                <option value="0">Select Bus Route</option>
			
			                                    <?php foreach ($allRouteList as $row){ ?>
                                                    <option <?php if( @$_GET['rid'] == $row['id']) { echo "selected"; }
				                                    ?>  value="<?php echo $row['id']; ?>"><?php echo
					                                    $row['name']; ?></option>
			                                    <?php } ?>

                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
						 
       
						</div>
						<!-- /.box-header -->
						<div class="box-body">
							<?php if(!empty($allMessageList)) { ?>
							<table  class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
									<th>Messages</th>
									<th>Class</th>
									<th>Division</th>
									<th>Created Date</th>
								</tr>
								</thead>
								<tbody> 
								
									<?php $i = 0; foreach($allMessageList as $row) { $i++; ?>
										<tr>
											<td><?php echo $i; ?></td>
                                            <td><?php echo getStudentNameById('student',$row['user_id']); ?> </td>
                                            <td><?php echo getStudentlastNameById('student',$row['user_id']); ?> </td>
											<td><?php echo $row['message']; ?> </td>
											<td><?php echo getNameById('class',$row['class_id']); ?> </td>
											<td><?php echo getNameById('section',$row['section_id']); ?> </td>
											<td><?php echo $row['created_at']; ?></td>
											
										</tr>
									<?php } ?>
								 
								
								</tbody>
								<tfoot>
								
								</tfoot>
							</table>
                                <?php echo  pagination($statement,$per_page,$page,$url='?'); ?>
							<?php } else { ?>

                                <div class="alert alert-danger">
                                    <strong>Error!</strong> <?php echo $empty; ?>
                                </div>
								
							
							<?php }	?>
						</div>
						<!-- /.box-body -->
					</div>
					<!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	
	
	
	<?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/8/2018
	 * Time: 9:47 PM
	 */
	
	date_default_timezone_set("Asia/Calcutta");
	
	if(!isset($_SESSION)) {
		session_start();
	}
	

	/*if (SITE_IS_LIVE )
	{
		ini_set('display_errors', 'off');
		error_reporting(0);
	} else {
		ini_set('display_errors', 'on');
		error_reporting(-1);
	}*/
	
	
	defined("DS")
		|| define("DS", DIRECTORY_SEPARATOR);
	
	defined("PAGE_PATH")
		|| define("PAGE_PATH", realpath(__DIR__."/../pages"));
	
	defined("PARTIAL_PATH")
	|| define("PARTIAL_PATH", realpath(__DIR__."/../partials"));
	
	defined("MOD_PATH")
	|| define("MOD_PATH", realpath(__DIR__."/../mod"));
	
	
	set_include_path(
		implode(
			PATH_SEPARATOR,
			[
				PARTIAL_PATH,
				get_include_path()
			]
		)
	
	);
	//echo get_include_path();

defined("DEFAULT_PAGE_FILE_NAME")
	|| define("DEFAULT_PAGE_FILE_NAME", "index");
	
defined("ERROR_PAGE_FILE_NAME")
	|| define("ERROR_PAGE_FILE_NAME", "error");
	
 
<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">
	
	<?php require_once 'header.php'; ?>
	<?php require_once 'navigation.php'; ?>
	
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				Class
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active"><a href="#">Class</a></li>
				
			</ol>
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-xs-12">
			 
					<div class="box">
						<div class="box-header">
							<h6 class="page-header">
							 
								<a id="" class="btn btn-primary" data-toggle="modal" data-target="#addClass">
									+ Add New Class</a>
							</h6>
						</div>
					 
						 <!-- /.box-header -->
						<div class="box-body">
							<table id="class-table" class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Id</th>
									<th>Name</th>
									<th>Created Date</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php
									$allClassList = getMultipleRecord('class');
								?>
								<?php if(!empty($allClassList)) { ?>
								<?php $i = 0; foreach($allClassList as $row) { $i++; ?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $row['name']; ?> </td>
										<td><?php echo $row['created_at']; ?></td>
										<td>
											<a href="javascript:void(0)" id="<?php echo $row['id']; ?>" class="btn btn-warning btn-xs mrg" data-placement="top" data-toggle="modal" data-target="#editClass" data-original-title="Edit"><i class="fa fa-edit"></i></a>
									        <?php if( $_SESSION['sessUser'] == 'admin') { ?>
											    <a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>" class="btn btn-danger btn-xs mrg delete_class" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
								<?php } ?>
							 
							 
								</tbody>
								<tfoot>
						 
								</tfoot>
							</table>
						</div>
						<!-- /.box-body -->
					</div>
					<!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	<!-- modal class start --->
	
	<!-- Modal -->
	<div id="addClass" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Class</h4>
				</div>
				<div class="modal-body">
					<div id="response"></div>
					<form id="class_form" class="class_form">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Class:</label>
									<input type="text" class="form-control" id="add_class" name="add_class" placeholder="Enter Class">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<button type="button"  onclick="addAcademyClass()" class="btn btn-primary btn-flat submit-trigger">Add Class</button>
									<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
								
								</div>
							</div>
						
						</div>
					
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal class end --->
	
	
	<!-- modal edit class start --->
	
	<!-- Modal -->
	<div id="editClass" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Edit Class</h4>
				</div>
				<div class="modal-body">
					<div id="update-response"></div>
					<div id="user_data"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal edit class end --->
	
	<!-- modal delete class start -->
	
	<!-- modal box for delte confirmation start --->
	<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Confirm</h4>
				</div>
				<div class="modal-body">
					<p><strong>Do you really want to delete this record ?</strong></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- end -->
	<!-- modal box for delte confirmation end ---->
	
	<!-- modal delete class end --->
	
	
	
	 <?php require_once 'sub-footer.php'; ?>
	
	 
</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

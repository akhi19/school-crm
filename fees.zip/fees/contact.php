<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">

    <?php require_once 'header.php'; ?>
    <?php require_once 'navigation.php'; ?>
    <?php




    $page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
    if ($page <= 0) $page = 1;

    $per_page = 20; // Set how many records do you want to display per page

    $startpoint = ($page * $per_page) - $per_page;


    $recordCount = "";
    $empty = "";




    $query = getStudentList(@$_GET['cid'],@$_GET['sid'], @$_GET['bid'], @$_GET['rid']);
    $statement = "`contact` WHERE {$query} ORDER BY IF(`name` RLIKE '^[a-z]', 1, 2), `name`";
    $allStudentList = pagingQuery($statement,$startpoint,$per_page);
    $recordCount = count($allStudentList);
    if(isset($_GET['cid']) !="" || isset($_GET['sid']) !="" || isset($_GET['bid']) !="" || isset($_GET['rid']) !="") {
        if(empty($allStudentList)) {
            $empty = 'There are no results matching your searching criteria.';
        }
    } else {

        $empty = 'There are currently no records.';
    }

    $getq = '';
    if(isset($_GET['cid'])&!empty($_GET)){
        if(isset($_GET['page'])){unset($_GET['page']);}
        $getq = "?".http_build_query($_GET);
    }





    ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Contact
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"><a href="#">Contact</a></li>

            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12 col-md-12">

                    <div class="box">
                        <div class="box-header">

                            <div class="col-md-8 pl0">
                                <div class="pull-left">

                                    <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-info sendContactMessage" >
                                            <i class="fa fa-envelope"></i> Send Message</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-warning" data-toggle="modal"
                                           data-target="#bulkUpload">
                                            <i class="fa fa-upload"></i> Import Contact</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                        <a href="/sample-contact.csv" class="btn btn-danger" >
                                            <i class="fa fa-file"></i> Sample CSV</a>
                                    <?php }  ?>
                                </div>

                            </div>
                            <div class="col-md-4">

                            </div>


                        </div>

                        <!-- /.box-header -->
                        <div class="box-body">

                            <div id="error-student"></div>


                            <?php if(!empty($allStudentList)) { ?>
                                <table  class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th><input type="checkbox" id="checkAll"></th>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Source</th>
                                        <th>Created Date</th>
                                        <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                            <th>Action</th>
                                        <?php }?>

                                    </tr>
                                    </thead>

                                    <?php $i = 0; foreach($allStudentList as $row) { $i++; ?>
                                        <tr>
                                            <td> <input type="checkbox" name="student_message" value="<?php echo
                                                $row['id']; ?>"
                                                        class="student_message"> </td>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['name']; ?> </td>
                                            <td><?php echo $row['email']; ?> </td>
                                            <td><?php echo $row['country_code'].$row['mobile_no']; ?> </td>
                                            <td><?php echo ucfirst($row['source']); ?> </td>
                                            <td><?php echo $row['created_at']; ?></td>
                                            <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                                <td>

                                                    <a href="javascript:void(0)" id="<?php echo $row['id']; ?>"
                                                       class="btn btn-warning btn-xs mrg" data-placement="top"
                                                       data-toggle="modal" data-target="#editContact"
                                                       data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                    <a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>" class="btn btn-danger btn-xs mrg delete_contact" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>

                                                </td>
                                            <?php } ?>

                                        </tr>
                                    <?php } ?>




                                </table>

                                <?php echo  pagination($statement,$per_page,$page,$url='?'); ?>
                            <?php } else { ?>
                                <div class="alert alert-danger">
                                    <strong>Error!</strong> <?php echo $empty; ?>
                                </div>


                            <?php }	?>

                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- modal class start --->



    <!-- modal edit class start --->

    <!-- Modal -->
    <div id="editContact" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Contact</h4>
                </div>
                <div class="modal-body">
                    <div id="update-response"></div>
                    <div id="user_data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal edit class end --->

    <!-- modal delete class start -->

    <!-- modal box for delte confirmation start --->
    <div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Confirm</h4>
                </div>
                <div class="modal-body">
                    <p><strong>Do you really want to delete this record ?</strong></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- end -->
    <!-- modal box for delte confirmation end ---->

    <!-- modal delete class end --->

    <!-- modal send message  start --->

    <!-- Modal -->
    <div id="sendContactMessage" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Send Message : <?php echo date("l jS \of F Y "); ?></h4>
                </div>
                <div class="modal-body">
                    <div id="message-response"></div>
                    <div id="message_data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal send message end --->


    <!-- Modal bulk upload start -->
    <div id="bulkUpload" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Import</h4>
                </div>
                <div class="modal-body">
                    <div id="response_csv"></div>
                    <form id="studentCSVImport" class="studentCSVImport">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="text">File:</label>
                                    <input type="file" name="studentFileToUpload" id="studentFileToUpload">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="button"  onclick="contactBulkUploadCsv()" class="btn btn-primary
                                    btn-flat submit-trigger">Upload</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                                </div>
                            </div>

                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal bulk upload end --->


    <?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

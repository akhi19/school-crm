<?php
require_once('./includes/functions.php'); 
if($_SESSION['sessid'] == ''){ redirect('/'); }
 $prod_data = array();

$data = array('ID','Name', 'Email', 'Mobile', 'Username','Role', 'Status', 'Date');

array_push($prod_data, $data);

 

	   $allUserList = getMultipleRecord('user');
	        $i = 0;   
	    foreach($allUserList as $row) {
	        
	        $i++;
	        
	        if($row['active'] == 1) {
	        	$status = 'Active';
	        } else {
		        $status = 'Not Active';
	        }
  
        array_push($prod_data, array($i,$row['name'],$row['email'],$row['mobile'],$row['username'],$row['user_type']
        ,$status,
	        $row['created_at']));
	    }
$temp_memory = fopen('php://memory', 'w');
/** loop through array  */
foreach ($prod_data as $line) {
    /** default php csv handler * */
    fputcsv($temp_memory, $line, ',');
}

/** rewrind the "file" with the csv lines * */
fseek($temp_memory, 0);

/** modify header to be downloadable csv file * */
header('Content-Type: application/csv');

header('Content-Disposition: attachement; filename="user_list.csv"');

/** Send file to browser for download */
fpassthru($temp_memory);
?>
 
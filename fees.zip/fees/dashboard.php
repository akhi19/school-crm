<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
	
	<div class="wrapper">
		
		<?php require_once 'header.php'; ?>
		<?php require_once 'navigation.php'; ?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					Dashboard
					<small>Control panel</small>
				</h1>
				<ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
					<li class="active">Dashboard</li>
				</ol>
			</section>
			
			<!-- Main content -->
			<section class="content">
				<!-- Small boxes (Stat box) -->
				<div class="row">
					<div class="col-lg-4 col-xs-12">
						<!-- small box -->
						<div class="small-box bg-aqua">
							<div class="inner">
								<h3><?php echo getTotalRecords('student'); ?></h3>
								
								<p>Students</p>
							</div>
							<div class="icon">
								<i class="ion ion-person-add"></i>
							</div>
							<a href="/student" class="small-box-footer">More info <i class="fa
							fa-arrow-circle-right"></i></a>
						</div>
					</div>
    <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
					<!-- ./col -->
					<div class="col-lg-4 col-xs-12">
						<!-- small box -->
						<div class="small-box bg-green">
							<div class="inner">
								<h3><?php echo getTotalRecords('user'); ?></h3>
								
								<p>Users</p>
							</div>
							<div class="icon">
								<i class="ion ion-person-add"></i>
							</div>
							<a href="/user" class="small-box-footer">More info <i class="fa
							fa-arrow-circle-right"></i></a>
						</div>
					</div>
<?php }?>
					<!-- ./col -->

                    <!-- ./col -->
                    <div class="col-lg-4 col-xs-12">
                        <!-- small box -->
                        <div class="small-box bg-yellow">
                            <div class="inner">
                                <h3><?php echo getTotalRecords('message'); ?></h3>

                                <p>Messages</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-envelope-o"></i>
                            </div>
                            <a href="/messages" class="small-box-footer">More info <i class="fa
							fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->



                </div>
			 
			
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		<?php require_once 'sub-footer.php'; ?>
		
	</div>
	<!-- ./wrapper -->
	
<?php require_once 'footer.php'; ?>
<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">

    <?php require_once 'header.php'; ?>
    <?php require_once 'navigation.php'; ?>
    <?php


    $allClassList = getMultipleRecord('class');
    $allSectionList =$allRouteList= array();
    if(isset($_GET['cid']) && $_GET['cid']>0){
         $allSectionList = getMultipleRecord('section',array('class_id'=>$_GET['cid']));
    }

    $allBusList = getMultipleRecord('bus_number');
    if(isset($_GET['bid']) && $_GET['bid']>0){
        $allRouteList = getMultipleRecord('bus_route',array('busno_id'=>$_GET['bid']));
    }


    $page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
    if ($page <= 0) $page = 1;

    $per_page = 20; // Set how many records do you want to display per page

    $startpoint = ($page * $per_page) - $per_page;


    $recordCount = "";
    $empty = "";




    $query = getStudentList(@$_GET['cid'],@$_GET['sid'], @$_GET['bid'], @$_GET['rid']);
    $statement = "`student` WHERE {$query} ORDER BY IF(`first_name` RLIKE '^[a-z]', 1, 2), `first_name`";
    $allStudentList = pagingQuery($statement,$startpoint,$per_page);
    $recordCount = count($allStudentList);
    if(isset($_GET['cid']) !="" || isset($_GET['sid']) !="" || isset($_GET['bid']) !="" || isset($_GET['rid']) !="") {
        if(empty($allStudentList)) {
            $empty = 'There are no results matching your searching criteria.';
        }
    } else {

        $empty = 'There are currently no records.';
    }

    $getq = '';
    if(isset($_GET['cid'])&!empty($_GET)){
        if(isset($_GET['page'])){unset($_GET['page']);}
        $getq = "?".http_build_query($_GET);
    }





    ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Student
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"><a href="#">Student</a></li>

            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12 col-md-12">

                    <div class="box">
                        <div class="box-header">

                            <div class="col-md-8 pl0">
                                <div class="pull-left">
                                    <?php if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-primary" data-toggle="modal" data-target="#addStudent">
                                            <i class="fa fa-plus"></i> Add New Student</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-info sendMessage" >
                                            <i class="fa fa-envelope"></i> Send Message</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                                        <a href="javascript:void(0)" class="btn btn-warning" data-toggle="modal"
                                           data-target="#bulkUpload">
                                            <i class="fa fa-upload"></i> Bulk Upload</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                                        <a href="/sample-student.csv" class="btn btn-danger" >
                                            <i class="fa fa-file"></i> Sample CSV</a>
                                    <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                        <a href="/student-report<?= $getq;?>" class="btn btn-success" >
                                            <i class="fa fa-file"></i> Export CSV</a>
                                    <?php }  ?>
                                </div>

                            </div>
                            <div class="col-md-4">

                            </div>

                            <form action="/student" method="get"  >
                                <div class="row">
                                    <div class="col-md-8 ">
                                        <div class="row mt-25">
                                            <div class="col-md-3">
                                                <select name="filterclass" id="filterclass" class="form-control" >
                                                    <option value="0">Select Class</option>

                                                    <?php foreach ($allClassList as $row){ ?>
                                                        <option <?php if(@$_GET['cid'] == $row['id']) { echo "selected"; }
                                                        ?>
                                                                value="<?php
                                                                echo $row['id'];
                                                                ?>"><?php
                                                            echo
                                                            $row['name']; ?></option>
                                                    <?php } ?>

                                                </select>
                                            </div>

                                            <div class="col-md-3">
                                                <select name="filtersection" id="filtersection" class="form-control">
                                                    <option value="0">Select Division</option>

                                                    <?php foreach ($allSectionList as $row){ ?>
                                                        <option <?php if( @$_GET['sid'] == $row['id']) { echo "selected"; }
                                                        ?>  value="<?php echo $row['id']; ?>"><?php echo
                                                            $row['name']; ?></option>
                                                    <?php } ?>

                                                </select>
                                            </div>


                                            <div class="col-md-3">
                                                <select name="filterBusno" id="filterBusno" class="form-control" onchange="this.form.submit()">
                                                    <option value="0">Select Bus No</option>

                                                    <?php foreach ($allBusList as $row){ ?>
                                                        <option <?php if( @$_GET['bid'] == $row['id']) { echo "selected"; }
                                                        ?>  value="<?php echo $row['id']; ?>"><?php echo
                                                            $row['name']; ?></option>
                                                    <?php } ?>

                                                </select>
                                            </div>

                                            <div class="col-md-3">
                                                <select name="filterBusroute" id="filterBusroute" class="form-control">
                                                    <option value="0">Select Bus Route</option>

                                                    <?php foreach ($allRouteList as $row){ ?>
                                                        <option <?php if( @$_GET['rid'] == $row['id']) { echo "selected"; }
                                                        ?>  value="<?php echo $row['id']; ?>"><?php echo
                                                            $row['name']; ?></option>
                                                    <?php } ?>

                                                </select>
                                            </div>




                                        </div>
                                    </div>
                                    <!--<div class="col-md-4">
                                        <div class="mt-25" style="display: block">
                                            <button type="submit" class="btn btn-success">GO</button>
                                        </div>



                                        <div class="mt-25 pull-right" style="display: none">
                                            <form action="/student">
                                                <input type="text" placeholder="Search.." name="srch">
                                                <button type="submit"><i class="fa fa-search"></i></button>
                                            </form>
                                        </div>
                                    </div>-->
                                </div>
                            </form>
                        </div>

                        <!-- /.box-header -->
                        <div class="box-body">

                            <div id="error-student"></div>


                            <?php if(!empty($allStudentList)) { ?>
                                <table  class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th><input type="checkbox" id="checkAll"></th>
                                        <th>Id</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Class</th>
                                        <th>Division</th>
                                        <th>Bus Number</th>
                                        <th>Bus Route</th>
                                        <th>Created Date</th>
                                        <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                            <th>Action</th>
                                        <?php }?>

                                    </tr>
                                    </thead>

                                    <?php $i = 0; foreach($allStudentList as $row) { $i++; ?>
                                        <tr>
                                            <td> <input type="checkbox" name="student_message" value="<?php echo
                                                $row['id']; ?>"
                                                        class="student_message"> </td>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['first_name']; ?> </td>
                                            <td><?php echo $row['last_name']; ?> </td>
                                            <td><?php echo getNameById('class',$row['class_id']); ?> </td>
                                            <td><?php echo getNameById('section',$row['section_id']); ?> </td>
                                            <td><?php echo getNameById('bus_number',$row['bus_no_id']); ?> </td>
                                            <td><?php echo getNameById('bus_route',$row['bus_route_id']); ?> </td>
                                            <td><?php echo $row['created_at']; ?></td>
                                            <?php if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                                                <td>

                                                    <a href="javascript:void(0)" id="<?php echo $row['id']; ?>"
                                                       class="btn btn-warning btn-xs mrg" data-placement="top"
                                                       data-toggle="modal" data-target="#editStudent"
                                                       data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                    <a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>" class="btn btn-danger btn-xs mrg delete_student" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>

                                                </td>
                                            <?php } ?>

                                        </tr>
                                    <?php } ?>




                                </table>

                                <?php echo  pagination($statement,$per_page,$page,$url='?'); ?>
                            <?php } else { ?>
                                <div class="alert alert-danger">
                                    <strong>Error!</strong> <?php echo $empty; ?>
                                </div>


                            <?php }	?>

                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- modal class start --->

    <!-- Modal -->
    <div id="addStudent" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Student</h4>
                </div>
                <div class="modal-body">
                    <div id="response"></div>
                    <form id="student_form" class="student_form">
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label for="text">Aadhar Card No:</label>
                                    <input type="text" class="form-control" id="aadhar_no"
                                           name="aadhar_no" placeholder="Enter Aadhar Card No">
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">GR No:</label>
                                            <input type="text" class="form-control" id="gr_no"
                                                   name="gr_no" placeholder="Enter GR No">
                                        </div>


                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Student ID:</label>
                                            <input type="text"  class="form-control" id="student_ids" name="student_ids" placeholder="Enter Student ID" >
                                        </div>

                                    </div>



                                </div>



                                <div class="form-group">
                                    <label for="text">First Name:</label>
                                    <input type="text" class="form-control" id="first_name"
                                           name="first_name" placeholder="Enter First Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Last Name:</label>
                                    <input type="text" class="form-control" id="last_name"
                                           name="last_name" placeholder="Enter Last Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Class:</label>
                                    <select class="form-control" id="promoteClass" name="class_id">
                                        <option value="">Please Select</option>
                                        <?php foreach ($allClassList as $row){ ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="text">Division:</label>

                                    <select class="form-control promoteSection" id="promoteSection" name="section_id">
                                        <option value="">Please Select Division</option>
                                        <?php foreach ($allSectionList as $row){ ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>




                                <div class="form-group" id="bus_option">
                                    <label for="text">Bus Option:</label>
                                    <label class="radio-inline">
                                        <input type="radio" value="1"  name="bus_op">Yes
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" value="0" name="bus_op">No
                                    </label>

                                </div>






                            </div>
                            <div class="col-md-6">


                                <div class="form-group">
                                    <label for="text">Father Name:</label>
                                    <input type="text" class="form-control" id="father_name"
                                           name="father_name" placeholder="Enter Father Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Father Mobile:</label>
                                    <input type="text" class="form-control" id="father_mobile"
                                           name="father_mobile" placeholder="Enter Father Mobile">
                                </div>

                                <div class="form-group">
                                    <label for="text">Mother Name:</label>
                                    <input type="text" class="form-control" id="mother_name"
                                           name="mother_name" placeholder="Enter Mother Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Mother Mobile:</label>
                                    <input type="text" class="form-control" id="mother_mobile"
                                           name="mother_mobile" placeholder="Enter Mother Mobile">
                                </div>

                                <div class="form-group">
                                    <label for="text">DOB:</label>
                                    <input type="text" class="form-control" id="dob" name="dob" class="dob">
                                </div>

                                <div class="form-group" id="message_option">
                                    <label for="text">Message Option:</label>
                                    <label class="checkbox-inline">
                                        <input type="checkbox" value="1"  name="messg_op[]">Father
                                    </label>
                                    <label class="checkbox-inline">
                                        <input type="checkbox" value="2" name="messg_op[]">Mother
                                    </label>

                                    <div id="message_option"><p style="display: none;color: #9f191f;">Please select
                                            atleast one
                                            option</p></div>
                                </div>

                                <div class="row" id="bus_option_student">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Bus No:</label>

                                            <select class="form-control abus_no_id" id="bus_no_id" name="bus_no_id">
                                                <option value="">Please Select Bus No</option>
                                                <?php foreach ($allBusList as $row){ ?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name'];
                                                        ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>


                                    </div>


                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Bus Route:</label>

                                            <select class="form-control abus_route_id" id="bus_route_id" name="bus_route_id">
                                                <option value="">Please Select Bus Route</option>

                                            </select>
                                        </div>


                                    </div>


                                </div>

                                <div class="form-group">
                                    <button type="button"  onclick="addAcademyStudent()" class="btn btn-primary
                                    btn-flat submit-trigger">Add Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                                </div>


                            </div>



                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal class end --->


    <!-- modal edit class start --->

    <!-- Modal -->
    <div id="editStudent" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Student</h4>
                </div>
                <div class="modal-body">
                    <div id="update-response"></div>
                    <div id="user_data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal edit class end --->

    <!-- modal delete class start -->

    <!-- modal box for delte confirmation start --->
    <div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Confirm</h4>
                </div>
                <div class="modal-body">
                    <p><strong>Do you really want to delete this record ?</strong></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- end -->
    <!-- modal box for delte confirmation end ---->

    <!-- modal delete class end --->

    <!-- modal send message  start --->

    <!-- Modal -->
    <div id="sendMessage" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Send Message : <?php echo date("l jS \of F Y "); ?></h4>
                </div>
                <div class="modal-body">
                    <div id="message-response"></div>
                    <div id="message_data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal send message end --->


    <!-- Modal bulk upload start -->
    <div id="bulkUpload" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Bulk Upload</h4>
                </div>
                <div class="modal-body">
                    <div id="response_csv"></div>
                    <form id="studentCSVImport" class="studentCSVImport">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="text">File:</label>
                                    <input type="file" name="studentFileToUpload" id="studentFileToUpload">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="button"  onclick="studentBulkUploadCsv()" class="btn btn-primary
                                    btn-flat submit-trigger">Upload</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                                </div>
                            </div>

                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal bulk upload end --->


    <?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

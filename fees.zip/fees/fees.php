    <!-- modal class start --->

    <!-- Modal -->
    <div id="addStudent" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Student</h4>
                </div>
                <div class="modal-body">
                    <div id="response"></div>
                    <form id="student_form" class="student_form">
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label for="text">Aadhar Card No:</label>
                                    <input type="text" class="form-control" id="aadhar_no"
                                           name="aadhar_no" placeholder="Enter Aadhar Card No">
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">GR No:</label>
                                            <input type="text" class="form-control" id="gr_no"
                                                   name="gr_no" placeholder="Enter GR No">
                                        </div>


                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Student ID:</label>
                                            <input type="text"  class="form-control" id="student_ids" name="student_ids" placeholder="Enter Student ID" >
                                        </div>

                                    </div>



                                </div>



                                <div class="form-group">
                                    <label for="text">First Name:</label>
                                    <input type="text" class="form-control" id="first_name"
                                           name="first_name" placeholder="Enter First Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Last Name:</label>
                                    <input type="text" class="form-control" id="last_name"
                                           name="last_name" placeholder="Enter Last Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Class:</label>
                                    <select class="form-control" id="promoteClass" name="class_id">
                                        <option value="">Please Select</option>
                                        <?php foreach ($allClassList as $row){ ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="text">Division:</label>

                                    <select class="form-control promoteSection" id="promoteSection" name="section_id">
                                        <option value="">Please Select Division</option>
                                        <?php foreach ($allSectionList as $row){ ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>




                                <div class="form-group" id="bus_option">
                                    <label for="text">Bus Option:</label>
                                    <label class="radio-inline">
                                        <input type="radio" value="1"  name="bus_op">Yes
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" value="0" name="bus_op">No
                                    </label>

                                </div>






                            </div>
                            <div class="col-md-6">


                                <div class="form-group">
                                    <label for="text">Father Name:</label>
                                    <input type="text" class="form-control" id="father_name"
                                           name="father_name" placeholder="Enter Father Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Father Mobile:</label>
                                    <input type="text" class="form-control" id="father_mobile"
                                           name="father_mobile" placeholder="Enter Father Mobile">
                                </div>

                                <div class="form-group">
                                    <label for="text">Mother Name:</label>
                                    <input type="text" class="form-control" id="mother_name"
                                           name="mother_name" placeholder="Enter Mother Name">
                                </div>

                                <div class="form-group">
                                    <label for="text">Mother Mobile:</label>
                                    <input type="text" class="form-control" id="mother_mobile"
                                           name="mother_mobile" placeholder="Enter Mother Mobile">
                                </div>

                                <div class="form-group">
                                    <label for="text">DOB:</label>
                                    <input type="text" class="form-control" id="dob" name="dob" class="dob">
                                </div>

                                <div class="form-group" id="message_option">
                                    <label for="text">Message Option:</label>
                                    <label class="checkbox-inline">
                                        <input type="checkbox" value="1"  name="messg_op[]">Father
                                    </label>
                                    <label class="checkbox-inline">
                                        <input type="checkbox" value="2" name="messg_op[]">Mother
                                    </label>

                                    <div id="message_option"><p style="display: none;color: #9f191f;">Please select
                                            atleast one
                                            option</p></div>
                                </div>

                                <div class="row" id="bus_option_student">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Bus No:</label>

                                            <select class="form-control abus_no_id" id="bus_no_id" name="bus_no_id">
                                                <option value="">Please Select Bus No</option>
                                                <?php foreach ($allBusList as $row){ ?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name'];
                                                        ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>


                                    </div>


                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text">Bus Route:</label>

                                            <select class="form-control abus_route_id" id="bus_route_id" name="bus_route_id">
                                                <option value="">Please Select Bus Route</option>

                                            </select>
                                        </div>


                                    </div>


                                </div>

                                <div class="form-group">
                                    <button type="button"  onclick="addAcademyStudent()" class="btn btn-primary
                                    btn-flat submit-trigger">Add Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

                                </div>


                            </div>



                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- modal class end --->

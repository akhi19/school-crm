<?php
/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/8/2018
 * Time: 10:00 PM
 */
require_once 'dbase.php';




function getPage()
{
    ob_start();
    $file = getPageInclude();
    ob_get_flush();
    require_once($file);
}


function isPage($identifier)
{
    $page = getPageIdentifier();
    return ($page == $identifier);
}

function getPageInclude()
{
    $path = getPagePathWithFilename();
	echo $path;
    if ( ! is_file($path))
    {
        return getPagePathWithFilename(ERROR_PAGE_FILE_NAME);
    }

    return $path;
}

function getPagePathWithFilename($identifier = null)
{
    if (is_null($identifier))
    {
        $identifier = getPageIdentifier();
    }

    $name = concatPageNameWithExtension($identifier);

    return PAGE_PATH . DS . $name;
}


function concatPageNameWithExtension($name)
{
    return rtrim($name, '.php').'.php';
}

function getPageIdentifier()
{
    $request = getRequest();

    if(empty($request['segments'][1]))
    {
        return DEFAULT_PAGE_FILE_NAME;
    }

    return $request['segments'][0];

}

function getRequest()
{
    $request = $_SERVER['REQUEST_URI'];
    $path = @explode("?", $request)[0];
    $query = isset($_GET) ? $_GET : [];
    $segments = explode("/", trim($path, "/"));

    return [
        'request' => $request,
        'path' => $path,
        'query' => $query,
        'segments' => $segments
    ];
}


function lastInsertID()
{
    global $conn;
    return mysqli_insert_id($conn);
}



function prepareInsert($table_name, $form_data)
{
    global $conn;
    $fields = array_keys($form_data);
    $sql = ("INSERT INTO ".$table_name."(`".implode('`,`', $fields)."`) VALUES('".implode("','", $form_data)."')");
	$query = mysqli_query($conn, $sql);
    if($query)
    {
        return true;
    }

    return false;
}

function insertIntoStudentFees($table_name, $gr_no,$class,$academic_year,$fees_months,$outstanding_fees)
{
    global $conn;
	mysqli_autocommit($conn, false);
	$flag = true;
	$query1 = ("INSERT INTO `student_pending_fees` (`gr_no`, `class`, `academic_year`, `fees_months`, `outstanding_fees`) VALUES ($gr_no, '', 0, '', $outstanding_fees)");
	$query2 = ("INSERT INTO `student_pending_fees` (`gr_no`, `class`, `academic_year`, `fees_months`, `outstanding_fees`) VALUES ($gr_no, '$class', $academic_year, '$fees_months', 0)");
    $result = mysqli_query($conn, $query1);
	if (!$result) {
		$flag = false;
	}
	$result = mysqli_query($conn, $query2);
	if (!$result) {
		$flag = false;
	}
	
	if ($flag) {
	    mysqli_commit($conn);
		mysqli_autocommit($conn, true);
	    return true;
	} else {
		mysqli_rollback($conn);
		mysqli_autocommit($conn, true);
	    return false;
	} 
}


function InsertIntoFeesTable($table_name,$class, $form_data)
{
    global $conn;
    $fields = array_keys($form_data);
    $sql = ("INSERT INTO class_fees(`class`,`academic_year`,`tuition_fees`,`development_fees`,`term_fees`,`computer_fees`,`total_fees`) VALUES ('$class',".implode(",", $form_data).")");
	$query = mysqli_query($conn, $sql);
    if($query)
    {
        return true;
    }

    return false;
}

function UpdateIntoFeesTable($table_name,$class, $academic_year,$tuition_fees,$development_fees,$term_fees,$computer_fees,$total_fees)
{
    global $conn;
	date_default_timezone_set("Asia/Calcutta");
	$date = date('Y-m-d H:i:s', time());
    $sql = ("UPDATE class_fees SET `tuition_fees`=$tuition_fees,`development_fees`=$development_fees,`term_fees`=$term_fees,`computer_fees`=$computer_fees,`total_fees`=$total_fees,`created_at` = '$date' WHERE `class` = $class AND `academic_year` = $academic_year ");
	$query = mysqli_query($conn, $sql);
    if($query)
    {
        return true;
    }

    return false;
}

function prepareUpdate($table_name, $form_data, $where_clause='')
{
    global $conn;
    $whereSQL = '';
    if(!empty($where_clause))
    {
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    $sql = "UPDATE ".$table_name." SET ";

    // loop and build the column /
    $sets = array();
    foreach($form_data as $column => $value)
    {
        $sets[] = "`".$column."` = '".$value."'";
    }
    $sql .= implode(', ', $sets);

    // append the where statement
    $sql .= $whereSQL;
    // run and return the query result
    //echo $sql; exit();
    $res = mysqli_query($conn, $sql);
    return $res;
}

function prepareDelete($table, $id)
{
    global $conn;
    $sql = "DELETE FROM $table WHERE id ='$id' ";
    $result = mysqli_query($conn, $sql);
    if($result)
    {
        return true;
    }
    return false;
}

function prepareClassFeesDelete($class,$academic_year)
{
    global $conn;
    $sql = "DELETE FROM class_fees WHERE class ='$class' AND academic_year = $academic_year ";
    $result = mysqli_query($conn, $sql);
    if($result)
    {
        return true;
    }
    return false;
}


function adminLogin($username, $password)
{
    global $conn;
    $sql = "SELECT * FROM admin WHERE username ='$username' AND password='$password' AND active = 1 ";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0 ? mysqli_fetch_array($result) : false;
}


function userLogin($username, $password)
{
    global $conn;
    $sql = "SELECT * FROM user WHERE username ='$username' AND password='$password' AND active = 1 ";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0 ? mysqli_fetch_array($result) : false;
}


function getMultipleRecord($table,$cond=array())
{
    global $conn;
    $c = '';
    if($cond){
        foreach ($cond as $key=>$val){
            $t[] = "`$key` = '$val'";
        }
        $c = " where ".implode(" and ",$t);
    }
    $sql = "SELECT * FROM $table $c ORDER BY IF(`name` RLIKE '^[a-z]', 1, 2), `name`  ";
    //var_dump($sql);
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}



function getWithoutSortRecord($table)
{
    global $conn;
    $sql = "SELECT * FROM $table  ";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}
function getWithoutGroupRecord($table)
{
    global $conn;
    $sql = "SELECT * FROM $table group by `message`  ";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}



function getSingleRecord($table, $id)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE id ='$id' ";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0 ? mysqli_fetch_array($result) : false;
}

function getClassYearwiseFees($class, $academic_year)
{
    global $conn;
    $sql = "SELECT * FROM class_fees WHERE class ='$class' AND academic_year = $academic_year ";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0 ? mysqli_fetch_array($result) : false;
}

function getTotalRecords($table)
{
    global $conn;
    $sql = "SELECT count(*) as totalRecord FROM $table ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['totalRecord'];
    }
    return false;
}

function getNameById($table, $id)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE id ='$id' ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['name'];
    }
    return false;
}

function dublicateRecord($table, $value)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE name ='$value' ";
    $result = mysqli_query($conn, $sql);
    //echo $sql; exit();
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return true;
    }
    return false;
}

function duplicateFeesRecord($table, $class, $academic_year)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE class ='$class' AND academic_year = $academic_year ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return true;
    }
    return false;
}

function getStudentNameById($table, $id)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE id ='$id' ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['first_name'];
    }
    return false;
}

function getStudentByAadhar($id)
{
    global $conn;
        $sql = "SELECT * FROM student where aadhar_card = '$id' ";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function getPendingFeesByGrNo($gr_no) {
    global $conn;
    $sql = "SELECT * FROM  student_pending_fees WHERE gr_no='$gr_no'";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return $result;
    // return $gr_no;
}

function getStudentByGR($id)
{
    global $conn;
        $sql = "SELECT * FROM student where gr_no = '$id' ";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function getStudentByFatherMobile($id)
{
    global $conn;
        $sql = "SELECT * FROM student where father_mobile = '$id' ";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function getStudentByMotherMobile($id)
{
    global $conn;
        $sql = "SELECT * FROM student where mother_mobile = '$id' ";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}



function getStudentlastNameById($table, $id)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE id ='$id' ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['last_name'];
    }
    return false;
}

function getStudentDetails($id)
{
    global $conn;
    $sql = "SELECT * FROM student where id in ($id)";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function getUserDetails($id)
{
    global $conn;
    $sql = "SELECT * FROM user where id in ($id) AND active = 1 AND user_type != 'admin'";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function getContactDetails($id)
{
    global $conn;
    $sql = "SELECT * FROM contact where id in ($id) and mobile_no != ''";
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}


function getLastRecord($table)
{
    global $conn;
    $sql = "SELECT * FROM $table  ORDER by `id` DESC LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['student_id'];
    }
    return false;
}


function getStudentList($cid, $sid,$bid ,$rid)
{
    global $conn;

    $where = " 1=1 ";

    if($sid !=0 && $bid !=0 && $cid !=0 && $rid !=0){
        $where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
    }else if($sid ==0 && $bid ==0 && $cid ==0 && $rid ==0){
        //$where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
    }else {
        if($bid != 0 ){
            $where .= " AND bus_no_id = $bid " ;
        }if($cid !=0 ){
            $where .= " AND class_id = $cid " ;
        }if($sid !=0) {
            $where .= " AND section_id = $sid " ;
        } if($rid !=0) {
            $where .= " AND bus_route_id = $rid " ;
        }
    }

    return $where;

    $sql = "SELECT * FROM student where $where ";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}


function getMessageList($cid, $sid,$bid ,$rid)
{
    global $conn;

    $where = " 1=1  ";

    $where = " 1=1 ";

    if($sid !=0 && $bid !=0 && $cid !=0 && $rid !=0){
        $where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
    }else if($sid ==0 && $bid ==0 && $cid ==0 && $rid ==0){
        //$where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
    }else {
        if($bid != 0 ){
            $where .= " AND bus_no_id = $bid " ;
        }if($cid !=0 ){
            $where .= " AND class_id = $cid " ;
        }if($sid !=0) {
            $where .= " AND section_id = $sid " ;
        } if($rid !=0) {
            $where .= " AND bus_route_id = $rid " ;
        }
    }
    return $where;

    $sql = "SELECT * FROM message where $where";

    //	echo $sql; exit();

    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}


function getIdByValue($table, $value)
{
    global $conn;
    $sql = "SELECT * FROM $table WHERE name ='$value' ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
        $out = mysqli_fetch_array($result);
        return $out['id'];
    }
    return false;
}



function activeClass($identifier)
{
    if(! isPage($identifier))
    {
        return null;
    }

    return ' class="active"';
}

function activeButton($act_id)
{

    $userDetails = getSingleRecord('user', $act_id);

    $userActive = empty($userDetails['active'] == 1) ? true : false;
    if($userActive == 0) {
        $id = 0;
        $label = "Inactive";
    } else {
        $id = 1;
        $label = "Active";
    }
    $out = "<lable class=\"switch\">";
    $out  .= "<a href=\"#\" class=\"add_to_active";
    $out .= $id == 0 ? " red" : null;
    $out .= "\" rel=\"";
    $out .= $act_id."_".$id;
    $out .= "\">{$label}</a>";
    $out .= "<span class=\"slider\"></span>";
    $out .= "</lable>";
    return $out;
}




function pagingQuery($table_name,$startpoint,$per_page)
{
    global $conn;
    $sql = "SELECT * FROM {$table_name} LIMIT {$startpoint} , {$per_page}";
    //echo $sql; exit();
    $query = mysqli_query($conn, $sql);
    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;
}

function pagination($query,$per_page=10,$page=1,$url='&')
{
    global $conn;
    $url = $_SERVER['REQUEST_URI']."&";


    if(explode("&", $url)[1] == '') {
        $url = $_SERVER['REQUEST_URI']."?";
    }


    $url = explode("page=", $url)[0];


    //var_dump($query);

    $sql = "SELECT COUNT(*) as `totalRecord` FROM  {$query}";
    $query = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($query);
    $recordCount =  $row['totalRecord'];

    $adjacents = "2";

    $prevlabel = "&lsaquo; Prev";
    $nextlabel = "Next &rsaquo;";
    $lastlabel = "Last &rsaquo;&rsaquo;";

    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;

    $prev = $page - 1;
    $next = $page + 1;

    $lastpage = ceil($recordCount/$per_page);

    $lpm1 = $lastpage - 1; // //last page minus 1

    $pagination = "";
    if($lastpage > 1){
        $pagination .= "<ul class='pagination'>";
        $pagination .= "<li class='page_info'>Page {$page} of {$lastpage}</li>";

        if ($page > 1) $pagination.= "<li><a href='{$url}page={$prev}'>{$prevlabel}</a></li>";

        if ($lastpage < 7 + ($adjacents * 2)){
            for ($counter = 1; $counter <= $lastpage; $counter++){
                if ($counter == $page)
                    $pagination.= "<li><a class='current'>{$counter}</a></li>";
                else
                    $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";
            }

        } elseif($lastpage > 5 + ($adjacents * 2)){

            if($page < 1 + ($adjacents * 2)) {

                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++){
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";
                }
                $pagination.= "<li class='dot'>...</li>";
                $pagination.= "<li><a href='{$url}page={$lpm1}'>{$lpm1}</a></li>";
                $pagination.= "<li><a href='{$url}page={$lastpage}'>{$lastpage}</a></li>";

            } elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {

                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";
                }
                $pagination.= "<li class='dot'>..</li>";
                $pagination.= "<li><a href='{$url}page={$lpm1}'>{$lpm1}</a></li>";
                $pagination.= "<li><a href='{$url}page={$lastpage}'>{$lastpage}</a></li>";

            } else {

                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>{$counter}</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page={$counter}'>{$counter}</a></li>";
                }
            }
        }

        if ($page < $counter - 1) {
            $pagination.= "<li><a href='{$url}page={$next}'>{$nextlabel}</a></li>";
            $pagination.= "<li><a href='{$url}page=$lastpage'>{$lastlabel}</a></li>";
        }

        $pagination.= "</ul>";
    }

    return $pagination;
}


function pagingQuerySearch($srch = null, $table, $value)
{
    global $conn;
    if (!empty($srch)) {
        $sql = "SELECT * FROM $table WHERE $value LIKE '%{$srch}%' ";
    }
    $query = mysqli_query($conn, $sql);

    $result = array();
    while($res = mysqli_fetch_assoc($query))
    {
        $result[] = $res;
    }
    return  $result;


}


function sendWhatsappmessage($mobile, $message, $filename,$filelink)
{


    if(!empty($filename)) {
        $data = [
            'phone' => $mobile, // Receivers phone
            'body' => $filelink, // Message
            'filename' => $filename
        ];
        $requesttype = "sendFile";
        $json = json_encode($data); // Encode data to JSON
        // URL for request POST /message
        $url = 'https://eu7.chat-api.com/instance5469/sendFile?token=d84laii298pl228r';
        $options = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => 'Content-type: application/json',
            'content' => $json
        ]
        ]);

        // Send a request
        $result = file_get_contents($url, false, $options);
        $doc_root = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME']);
        $txt = "Date :".date('d/m/Y H:i A').PHP_EOL
            ."Request :".$json.PHP_EOL
            ."Response :".$result.PHP_EOL;
        $myfile = file_put_contents($doc_root.'/logs/logs_'.date('d_m_Y').'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
    }

    $data1 = [
        'phone' => $mobile, // Receivers phone
        'body' => $message  // Message
    ];
    $requesttype = "message";

    //print_r($data); exit();
    $json1 = json_encode($data1); // Encode data to JSON
    // URL for request POST /message
    $url = 'https://eu7.chat-api.com/instance5469/message?token=d84laii298pl228r';
    $options = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-type: application/json',
        'content' => $json1
    ]
    ]);

    // Send a request
    $result = file_get_contents($url, false, $options);
    $doc_root = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME']);
    $txt = "Date :".date('d/m/Y H:i A').PHP_EOL
        ."Request :".$json1.PHP_EOL
        ."Response :".$result.PHP_EOL;
    $myfile = file_put_contents($doc_root.'/logs/logs_'.date('d_m_Y').'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);


    if($result) {
        $result = json_decode($result,true);
        if($result['sent']==true){
            return 1;
        }else{
            return 0;
        }

    }

    return 0;
}

function sendWhatsappmessage_old($mobile, $message, $file)
{


    if(!empty($file)) {
        $data = [
            'phone' => $mobile, // Receivers phone
            'body' => $message, // Message
            'filename' => $file
        ];
        $requesttype = "sendFile";
    }else{
        $data = [
            'phone' => $mobile, // Receivers phone
            'body' => $message  // Message
        ];
        $requesttype = "message";
    }
    //print_r($data); exit();

    $json = json_encode($data); // Encode data to JSON
    /*// URL for request POST /message
    $url = 'https://eu7.chat-api.com/instance5469/sendFile?token=d84laii298pl228r';
        $options = stream_context_create(['https' => [
            'method'  => 'POST',
            'header'  => 'Content-type: application/json',
            'content' => $json
        ]
    ]);*/

    // Send a request
    $result = curl_request($requesttype, $data);
    //var_dump($result);
    $doc_root = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME']);
    $txt = "Date :".date('d/m/Y H:i A').PHP_EOL
        ."Request :".$json.PHP_EOL
        ."Response :".$result.PHP_EOL;
    $myfile = file_put_contents($doc_root.'/logs/logs_'.date('d_m_Y').'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);

    if($result) {
        $result = json_decode($result,true);
        if($result['sent']==true){
            return 1;
        }else{
            return 0;
        }

    }

    return 0;
}

function redirect($url=null)
{

    if($url != null) {
        header("Location: {$url}");
        exit;
    }
}

function url(){
    if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    return $protocol . "://" . $_SERVER['HTTP_HOST'];
}


function curl_request($requesttype, $data){
    $data = http_build_query($data);
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://eu7.chat-api.com/instance5469/$requesttype?token=d84laii298pl228r",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/x-www-form-urlencoded",
            "Postman-Token: e37f9cd4-3a1a-45db-a071-48dea1208448",
            "cache-control: no-cache",
            "header: Content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        return "cURL Error #:" . $err;
    } else {
        return $response;
    }
}
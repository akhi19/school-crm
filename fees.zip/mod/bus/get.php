<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/19/2018
	 * Time: 1:56 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST) {
		$response = [];
		
		$id = $_POST['id'];
		
		$busname = getSingleRecord('bus', $id);
		
		if($busname > 0) {
			$response['busname'] = $busname['bus_area'];
		}
		
		echo json_encode($response);
	}
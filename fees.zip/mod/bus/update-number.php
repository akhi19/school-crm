<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		
		$add_busnumber = $_POST['add_busnumber'];
		$busnumber_id = $_POST['busnumber_id'];
		
		$busnumberData = array(
			'name'	=> $add_busnumber,
			'updated_at' => date("Y-m-d h:i:s")
		
		);
		
		
		$updateBusnumberData = prepareUpdate('bus_number', $busnumberData, " WHERE id =  $busnumber_id ");
		
		if($updateBusnumberData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Number updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
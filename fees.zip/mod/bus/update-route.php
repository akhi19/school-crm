<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
        $busno_id = trim($_POST['busno_id']);
		$add_busroute = $_POST['add_busroute'];
		$busroute_id = $_POST['busroute_id'];
		
		$busrouteData = array(
			'name'	=> $add_busroute,
			'updated_at' => date("Y-m-d h:i:s"),
            'busno_id' => $busno_id
		
		);
		
		
		$updateBusrouteData = prepareUpdate('bus_route', $busrouteData, " WHERE id =  $busroute_id ");
		
		if($updateBusrouteData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Route updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
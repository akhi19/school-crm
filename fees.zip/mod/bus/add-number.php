<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$add_busnumber = trim($_POST['add_busnumber']);
		
		$busnumberData = array(
			'name'	=> $add_busnumber
		);
		
		
		$addBusnumberData = prepareInsert('bus_number', $busnumberData);
		
		if($addBusnumberData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Number added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
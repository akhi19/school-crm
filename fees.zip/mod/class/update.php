<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		
		$add_class = $_POST['add_class'];
		$class_id = $_POST['class_id'];
		
		$classData = array(
			'name'	=> $add_class,
			'updated_at' => date("Y-m-d h:i:s")
			
		);
		
		
		$updateClassData = prepareUpdate('class', $classData, " WHERE id =  $class_id ");
		
		if($updateClassData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Class updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
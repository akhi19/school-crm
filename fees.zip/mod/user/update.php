<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		$user_id = $_POST['user_id'];
		$userDetails = getSingleRecord('user', $user_id);
		
		$add_user = $_POST['add_user'];
		$add_email = $_POST['add_email'];
		$add_password = !empty($_POST['add_password']) ? sha1($_POST['add_password']) : $userDetails['password'];
		$add_usertype = $_POST['add_usertype'];
		$add_username = $_POST['add_username'];
		$add_mobile = $_POST['add_mobile'];
		 
		
		$userData = array(
			'name'	=> $add_user,
			'email'	=> $add_email,
			'password'	=> $add_password,
			'user_type' => $add_usertype,
			'username' => $add_username,
			'mobile' => $add_mobile,
			
		);
		
		
		$updateUserData = prepareUpdate('user', $userData, " WHERE id =  $user_id ");
		
		if($updateUserData)
		{
			$response['status'] = true;
			$response['message'] = "<p>User updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
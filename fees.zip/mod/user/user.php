<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$userIds = "";
	foreach($_POST['userIds'] as $value)
	{
		$userIds .= $value.",";
	}

?>

<form id="whatsapp_userform" class="whatsapp_userform">
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Message:</label>
				<textarea class="form-control" rows="5" id="message" name="message"></textarea>
				<input type="hidden" value="<?php echo $userIds; ?>" name="user_id" id="user_id" />
			</div>
		</div>
        <div class="col-md-12">
            <div class="form-group">
                <label for="text">File:</label>
                <input type="file" name="sendFile" id="sendFile" class="form-control">
            </div>
        </div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="sendUserWhatsapp()" class="btn btn-primary btn-flat
                                    submit-trigger">Send Whatsapp</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	
	
	if($_POST)
	{
		$response = [];
		$id = $_POST['id'];
		$job = $id[1];
		$id = explode("-", $id);
		
		$active = ($id[1] == 0) ? 1 : 0;
		
		$userData = array(
			'active' => $active,
			'updated_at' => date("Y-m-d h:i:s")
		);
		
		//print_r($userData); exit();
		
		$addUserData = prepareUpdate('user', $userData, " WHERE id =  $id[0] ");
		
		switch($job) {
			
			case 0:
				$response['job'] = 1;
				break;
			
			case 1:
				$response['job'] = 0;
				break;
			
		}
		
		if($addUserData)
		{
			$response['status'] = true;
			$response['message'] = "<p>User data updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
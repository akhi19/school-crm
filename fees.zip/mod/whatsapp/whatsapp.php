<?php
/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/9/2018
 * Time: 1:59 AM
 */

require_once '../../includes/config.php';
require_once '../../includes/functions.php';



if($_POST)
{
    $response = [];
    $uploadOk = 1;

    $message =$_POST['message'];
    //	$sendFile = $_FILES['sendFile']['tmp_name'];
    $student_id = rtrim($_POST['student_id'], ",");
    $temp = explode(".",$_FILES["sendFile"]["name"]);
    $sendFile = $imageurl='';
    if(!empty($_FILES["sendFile"]["name"])){
        $doc_root = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME'])."/uploads/";
        $dir = date('dmY');
        $updir = $doc_root.$dir;
        if(!file_exists($updir)){
            mkdir($updir);
        }
        $sendFile = basename($_FILES["sendFile"]["name"]);
        $imageFileType = strtolower(pathinfo($sendFile,PATHINFO_EXTENSION));
        $sendFile=uniqid().".".$imageFileType;

        if (!move_uploaded_file($_FILES["sendFile"]["tmp_name"],$updir."/". $sendFile)) {
            $uploadOk = 0;
            $response['status'] = 133;
            $response['message'] = "<p>File not uploaded. Please try again later!</p>";
        }else
        {
            $imageurl = url()."/uploads/".$dir."/".$sendFile;
        }
    }

    if($uploadOk == 1){
        $studentDetails = getStudentDetails($student_id);


        $result = array();
        foreach ($studentDetails as $value)
        {

            $messageData = array(
                'class_id' => $value['class_id'],
                'section_id' => $value['section_id'],
                'bus_no_id' => $value['bus_no_id'],
                'bus_route_id' => $value['bus_route_id'],
                'user_id' => $student_id,
                'message'=> $message,
                'send_file' => $imageurl
            );

            //send message from whatsapp start

            $mobile_number = explode("," ,$value['opt_message']);

            if($mobile_number[0] == 1)
            {
                if(!empty($value['father_mobile'])) {
                    $father_mobile = "91".$value['father_mobile'];
                    $result[] =  sendWhatsappmessage($father_mobile,$message,$sendFile,$imageurl);
                }
            }

            if($mobile_number[0] == 2)
            {
                if(!empty($value['mother_mobile'])) {
                    $mother_mobile = "91".$value['mother_mobile'];
                    $result[] =  sendWhatsappmessage($mother_mobile,$message,$sendFile,$imageurl);
                }

            }


            prepareInsert('message', $messageData);


        }

        if(in_array(0,$result) && in_array(1,$result) )
        {

            $response['status'] = true;
            $response['message'] = "<p>Whatsapp Message Send to some Successfully</p>";


        } else if(in_array(0,$result))
        {
            $response['status'] = 133;
            $response['message'] = "<p>Some problem occured. Please try again later!</p>";

        }else{
            $response['status'] = true;
            $response['message'] = "<p>Whatsapp Message Send to all Successfully</p>";
        }
    }





//send message from whatsapp end


echo json_encode($response);



}
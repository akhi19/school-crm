<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
 
	
	if($_POST)
	{
		$response = [];
        
        $gr_no = trim($_POST['add_fees_gr_no']);
		$first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $outstanding_fees = trim($_POST['outstanding_fees']);
		$present_class = trim($_POST['present_class']);
        $fees_from_month = trim($_POST['fees_month']);
        $academic_year = trim($_POST['academic_year']);
		
		$addFeesData = insertIntoStudentFees('student_pending_fees', $gr_no,$present_class,$academic_year,$fees_from_month,$outstanding_fees);
        
		if($addFeesData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Fees for student added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
            $response['message'] = "<p>Some problem occured. Please try again later!</p>";
		}
		
		echo json_encode($response);
		
		
	}
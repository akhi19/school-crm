<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$academic_year = trim($_POST['academic_year']);
		$tuition_fees = trim($_POST['tuition_fees']);
		$development_fees = trim($_POST['development_fees']);
		$term_fees = trim($_POST['term_fees']);
		$computer_fees = trim($_POST['computer_fees']);
		$total_fees = trim($_POST['total_fees']);
        $class_id = $_POST['class_id'];

        	$addFeesData = UpdateIntoFeesTable('class_fees',$class_id,$academic_year, $tuition_fees,$development_fees,$term_fees,$computer_fees,$total_fees);
    		
    		if($addFeesData)
    		{
    			$response['status'] = true;
    			$response['message'] = "<p>Class fees added Successfully</p>";
    			
    		} else
    		{
    			$response['status'] = false;
    			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
    			
    		} 	
	 
		echo json_encode($response);
		
		
	}
	
<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
    $class_id = $_POST['class_id'];
	$academic_year = $_POST['academic_year'];
	$tuition_fees = $_POST['tuition_fees'];
	$development_fees = $_POST['development_fees'];
	$term_fees = $_POST['term_fees'];
	$computer_fees = $_POST['computer_fees'];
	$total_fees = $_POST['total_fees'];
	if($_POST){
		$sectionDetails = getSingleRecord('section', $id);
        $allClassList = getMultipleRecord('class');
	}
?>

<form id="update_class_fees_form" class="update_class_fees_form">
	<div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="text">Class:</label>
                <select name="class_id" id="class_id" class="form-control">
                    <option value="0">Select Class</option>

                    <?php foreach ($allClassList as $row){ ?>
                        <option value="<?php echo $row['name'];?>"><?php echo $row['name']; ?></option>
                    <?php } ?>

                </select>
            </div>
        </div>
			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Academic Year:</label>
  					<input type="text" class="form-control" id="academic_year" name="academic_year" placeholder="Academic Year">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Tuition Fees:</label>
  					<input type="text" class="form-control" id="tuition_fees" name="tuition_fees" placeholder="Tuition Fees">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Development Fees:</label>
  					<input type="text" class="form-control" id="development_fees" name="development_fees" placeholder="Development Fees">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Term Fees:</label>
  					<input type="text" class="form-control" id="term_fees" name="term_fees" placeholder="Term Fees">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Computer Fees:</label>
  					<input type="text" class="form-control" id="computer_fees" name="computer_fees" placeholder="Computer Fees">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<label for="text">Total Fees:</label>
  					<input type="text" class="form-control" id="total_fees" name="total_fees" placeholder="Total Fees">
  				</div>
  			</div>
  			<div class="col-md-12">
  				<div class="form-group">
  					<button type="button"  onclick="editAcademyFees()" class="btn btn-primary btn-flat submit-trigger">Edit Fees</button>
  					<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
  				
  				</div>
  			</div>
	
	</div>

</form>
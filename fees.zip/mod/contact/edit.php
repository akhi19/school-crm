<?php
/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/9/2018
 * Time: 8:01 AM
 */

require_once '../../includes/config.php';
require_once '../../includes/functions.php';
$id = $_POST['id'];
if($_POST){
    $studentDetails = getSingleRecord('contact', $id);
}
?>

<form id="update_contact_form" class="update_contact_form">
    <div class="row">
        <div class="col-md-12">


            <div class="form-group">
                <label for="text">Name:</label>
                <input type="text" class="form-control" id="name"
                       name="name" value="<?php echo trim($studentDetails['name']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Email:</label>
                <input type="text" class="form-control" id="email"
                       name="email" value="<?php echo trim($studentDetails['email']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Mobile:</label>
                <input type="text" class="form-control" id="mobile"
                       name="mobile" value="<?php echo trim($studentDetails['mobile_no']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Country Code:</label>
                <input type="text" class="form-control" id="country_code"
                       name="country_code" value="<?php echo trim($studentDetails['country_code']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Source:</label>
                <select class="form-control" id="source" name="source">
                    <option  value=""> Select Source</option>
                    <option <?= isset($studentDetails['source']) && $studentDetails['source']=='website'?"selected":'';?> value="website">Website</option>
                    <option <?= isset($studentDetails['source']) && $studentDetails['source']=='google'?"selected":'';?> value="google">Google</option>
                    <option <?= isset($studentDetails['source']) && $studentDetails['source']=='facebook'?"selected":'';?> value="facebook">Facebook</option>
                </select>
            </div>







            <input type="hidden" value="<?php echo $studentDetails['id']; ?>" id="id" name="id" />

            <div class="form-group">
                <button type="button"  onclick="editContactRecord()" class="btn btn-primary
                                    btn-flat submit-trigger">Update Contact</button>
                <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

            </div>
        </div>
    </div>

</form>
<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/17/2018
	 * Time: 11:20 PM
	 */
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	$response = [];
	$fileName = $_FILES["studentFileToUpload"]["tmp_name"];
	
	
	if ($_FILES["studentFileToUpload"]["size"] > 0) {
		
		$file = fopen($fileName, "r");
		
		$i = 0;
		while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
			if($i == 1) {
				
				try {
                $student_data = array(
                    'name'	=> $column[0],
                    'email'	=> $column[1],
                    'mobile_no' => $column[2],
                    'country_code' =>  ($column[3]=='')?91:$column[3],
                    'source' => ($column[4]=='')?'website':$column[4],
                    'created_at' => date("Y-m-d h:i:s")
                );

                prepareInsert('contact', $student_data);
						

					
					
						
				
			}
				catch(Exception $e) {
						$response['status'] = "error";
						$response['message'] = '<p style="color:white">Error in import file!</p>';
						echo json_encode($response);
						return;
					}
				
			}
			$i = 1;
		}
		
		$response['status'] = "success";
		$response['message'] = '<p style="color:#fff">Bulk User data added successfully!</p>';
	} else {
		$response['message'] = '<p style="color:red">Please try again later!</p>';
	}
	
	echo json_encode($response);
 
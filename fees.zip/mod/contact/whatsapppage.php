<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$studentIds = ""; 
	foreach($_POST['studentIds'] as $value)
	{
		$studentIds .= $value.","; 
	}
	
	$students = (count($_POST['studentIds']) > 1) ? 's': NULL;
	
?>
<h3>(<?php echo count($_POST['studentIds']); ?>) Contact<?php echo $students; ?> Selected</h3>
<form id="whatsapp_form" class="whatsapp_form">
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Message:</label>
				<textarea class="form-control" rows="5" id="message" name="message"></textarea>
				<input type="hidden" value="<?php echo $studentIds; ?>" name="student_id" id="student_id" />
			</div>
		</div>

        <div class="col-md-12">
            <div class="form-group">
                <label for="text">File:</label>
                <input type="file" name="sendFile" id="sendFile" class="form-control">
            </div>
        </div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="sendContactWhatsapp()" class="btn btn-primary btn-flat
                                    submit-trigger">Send Whatsapp</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


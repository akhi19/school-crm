<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
	if($_POST){
		$studentDetails = getSingleRecord('student', $id);
		$allBusList = getMultipleRecord('bus_number');
		$allRouteList = getMultipleRecord('bus_route');
        $busno_id = $studentDetails['bus_no_id'];
        $allRouteList = getMultipleRecord('bus_route',array('busno_id'=>$busno_id));

	}
?>

<form id="update_student_form" class="update_student_form">
    <div class="row">
        <div class="col-md-6">
            
            <div class="form-group">
                <label for="text">Aadhar Card No:</label>
                <input type="text" class="form-control" id="aadhar_no"
                       name="aadhar_no"  value="<?php echo $studentDetails['aadhar_card']; ?>">
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="text">Student ID:</label>
                        <input type="text"  class="form-control" id="student_ids" name="student_ids"
                               value="<?php echo $studentDetails['student_id']; ?>"
                        >
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="text">GR No:</label>
                        <input type="text" class="form-control" id="gr_no"
                               name="gr_no"  value="<?php echo $studentDetails['gr_no']; ?>">
                    </div>
                </div>
            </div>
            
            
            
            
            
            <div class="form-group">
                <label for="text">First Name:</label>
                <input type="text" class="form-control" id="first_name"
                       name="first_name" value="<?php echo trim($studentDetails['first_name']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Last Name:</label>
                <input type="text" class="form-control" id="last_name"
                       name="last_name" value="<?php echo trim($studentDetails['last_name']); ?>">
            </div>
			<?php
				$allClassList = getMultipleRecord('class');
				$allSectionList = getMultipleRecord('section');
			?>
            <div class="form-group">
                <label for="text">Class:</label>
                <select class="form-control" id="promoteClass" name="class_id">
					<?php foreach ($allClassList as $row){ ?>
                        <option <?php if( $studentDetails['class_id'] == $row['id']) {
	                        echo "selected";
                        } ?> value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
					<?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="text">Division:</label>

                <select class="form-control promoteSection" id="promoteSection" name="section_id">
					<?php foreach ($allSectionList as $row){ ?>
                        <option <?php if( $studentDetails['section_id'] == $row['id']) {
                            echo "selected";
                        } ?> value="<?php echo $row['id'];
                        ?>"><?php echo $row['name']; ?></option>
					<?php } ?>
                </select>
            </div>

            

            <div class="form-group">
                <label for="text">Bus Option:</label>
                <label class="radio-inline">
                    <input type="radio" value="1"  name="bus_op_edit"  <?php if($studentDetails['opt_bus'] == 1) { echo
                    "checked"; } ?>>Yes
                </label>
                <label class="radio-inline">
                    <input type="radio" value="0" name="bus_op_edit" <?php if($studentDetails['opt_bus'] == 0) { echo "checked"; } ?>>No
                </label>

            </div>

        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="text">Father Name:</label>
                <input type="text" class="form-control" id="father_name"
                       name="father_name" value="<?php echo trim($studentDetails['father_name']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Father Mobile:</label>
                <input type="text" class="form-control" id="father_mobile"
                       name="father_mobile" value="<?php echo trim($studentDetails['father_mobile']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Mother Name:</label>
                <input type="text" class="form-control" id="mother_name"
                       name="mother_name" value="<?php echo trim($studentDetails['mother_name']); ?>">
            </div>

            <div class="form-group">
                <label for="text">Mother Mobile:</label>
                <input type="text" class="form-control" id="mother_mobile"
                       name="mother_mobile" value="<?php echo trim($studentDetails['mother_mobile']); ?>">
            </div>
          
             <div class="form-group">
                    <label for="text">DOB:</label>
                    <input type="text" class="form-control dob"  name="dob" value="<?php echo $studentDetails['dob']; ?>">
                </div>
                
                
            <div class="form-group">
                <label for="text">Message Option:</label>
                <label class="checkbox-inline">
                    <input type="checkbox" value="1" <?php if( @explode(",",$studentDetails['opt_message'])[0] == 1 ) {
				        echo "checked";
			        } ?>  name="messg_op[]">Father
                </label>
                <label class="checkbox-inline">
                    <input type="checkbox" value="2" <?php if( @explode(",",$studentDetails['opt_message'])[1] == 2 || @explode(",",$studentDetails['opt_message'])[0]  == 2) {
				        echo "checked";
			        }  ?> name="messg_op[]">Mother
                </label>


            </div>
 

            <div class="row" id="bus_option_student">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="text">Bus No:</label>

                        <select class="form-control bus_no_id ebus_no_id" id="bus_no_id" name="bus_no_id">
                            <option value="">Please Select Bus No</option>
				            <?php foreach ($allBusList as $row){ ?>
                                <option <?php if($row['id'] == $studentDetails['bus_no_id']) { echo "selected"; } ?>
                                        value="<?php echo $row['id']; ?>"><?php echo $row['name'];
						            ?></option>
				            <?php } ?>
                        </select>
                    </div>


                </div>


                <div class="col-md-6">
                    <div class="form-group">
                        <label for="text">Bus Route:</label>

                        <select class="form-control bus_route_id ebus_route_id" id="bus_route_id" name="bus_route_id">
                            <option value="">Please Select Bus Route</option>
				            <?php foreach ($allRouteList as $row){ ?>
                                <option  <?php if($row['id'] == $studentDetails['bus_route_id']) { echo "selected"; } ?> value="<?php echo $row['id']; ?>"><?php echo $row['name'];
						            ?></option>
				            <?php } ?>
                        </select>
                    </div>


                </div>

                <div class="col-md-6" style="display: none">
                    <div class="form-group">
                        <label for="text">Bus Area:</label>
                        <input type="text" disabled class="form-control" name="busarea" id="busarea" />

                    </div>


                </div>



            </div>
            
            <input type="hidden" value="<?php echo $studentDetails['id']; ?>" id="student_id" name="student_id" />

            <div class="form-group">
                <button type="button"  onclick="editAcademyStudent()" class="btn btn-primary
                                    btn-flat submit-trigger">Update Student</button>
                <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>

            </div>


        </div>



    </div>

</form>
<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
 
	
	if($_POST)
	{
		$response = [];
		
		$first_name = trim($_POST['first_name']);
		$last_name = trim($_POST['last_name']);
		$class_id = trim($_POST['class_id']);
		$section_id = trim($_POST['section_id']);
	    $messg_op = !empty($_POST['messg_op']) ? implode(",",  $_POST['messg_op']) : NUll;
		$father_name = trim($_POST['father_name']);
		$father_mobile = trim($_POST['father_mobile']);
		$mother_name = trim($_POST['mother_name']);
		$mother_mobile = trim($_POST['mother_mobile']);
		$aadhar_no = trim($_POST['aadhar_no']);
		$gr_no = trim($_POST['gr_no']);
		$dob = date("Y-m-d", strtotime($_POST['dob']));
		//$bus_detail = $_POST['bus_detail'];
		$bus_op = $_POST['bus_op'];
		$student_ids = trim($_POST['student_ids']);
		$bus_route_id  =  trim($_POST['bus_route_id']);
		$bus_no_id  =  trim($_POST['bus_no_id']);
		
		
	 
		
		
		$studentData = array(
			'aadhar_card' => $aadhar_no,
			'gr_no' => $gr_no,
			'dob' => $dob,
			'bus_no_id' => $bus_no_id,
			'bus_route_id' => $bus_route_id,
			'opt_bus' => $bus_op,
			'student_id' => $student_ids,
			'first_name'	=> $first_name,
			'last_name'	=> $last_name,
			'class_id'	=> $class_id,
			'section_id'	=> $section_id,
			'father_name'	=> $father_name,
			'father_mobile'	=> $father_mobile,
			'mother_name'	=> $mother_name,
			'mother_mobile'	=> $mother_mobile,
			'opt_message' => $messg_op
		 
			
		);
		
		
		$addStudentData = prepareInsert('student', $studentData);
		
		if($addStudentData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Student added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$add_busroute = trim($_POST['add_busroute']);
        $busno_id = trim($_POST['busno_id']);
		
		$busrouteData = array(
			'name'	=> $add_busroute,
            'busno_id' => $busno_id
		);
		
		
		$addBusrouteData = prepareInsert('bus_route', $busrouteData);
		
		if($addBusrouteData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Route added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
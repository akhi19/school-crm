<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$add_bus_no = $_POST['add_bus_no'];
		$add_bus_area = $_POST['add_bus_area'];
		
		$busData = array(
			'bus_no'	=> $add_bus_no,
			'bus_area'	=> $add_bus_area
		);
		
		
		$addBusData = prepareInsert('bus', $busData);
		
		if($addBusData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
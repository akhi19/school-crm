<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';


if($_POST['id'])
{
    $id=$_POST['id'];

    $allSectionList = getMultipleRecord('section',array('class_id'=>$id));
    ?>
    <option value="">Select Division</option>
    <?php
    foreach ($allSectionList as $row){ ?>
        <option value="<?php
            echo $row['id'];
            ?>"><?php
            echo
            $row['name']; ?></option>
    <?php }
}
?>
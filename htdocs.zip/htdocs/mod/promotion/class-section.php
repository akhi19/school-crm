<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	
	if($_POST)
	{
		$response = [];
		
		$id = $_POST['id'];
		
		$getAllClass = getMultipleRecord('class');
		$getAllSection = getMultipleRecord('section');
		$getStudentDetails = getSingleRecord('student',$id);
		$out = "";
		$outSection = "";
		foreach( $getAllClass as $value){
			$out .= '<option value="';
			$out .= $value['id'];
			$out .= '"';
			if($value['id'] == $getStudentDetails['class_id']) {
				$out .= ' selected';
			}
			$out .= ' >';
			$out .= $value['name'];
			$out .= '</option>';
		}
		
		foreach( $getAllSection as $value){
			$outSection .= '<option value="';
			$outSection .= $value['id'];
			$outSection .= '"';
			if($value['id'] == $getStudentDetails['section_id']) {
				$outSection .= ' selected';
			}
			$outSection .= ' >';
			$outSection .= $value['name'];
			$outSection .= '</option>';
		}
		$response['studentclass'] = $out;
		$response['studentsection'] = $outSection;
		echo json_encode($response);
		
		
	}
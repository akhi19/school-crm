<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
    $class_id = $_POST['class_id'];
	if($_POST){
		$sectionDetails = getSingleRecord('section', $id);
        $allClassList = getMultipleRecord('class');
	}
?>

<form id="update_section_form" class="update_section_form">
	<div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="text">Section:</label>
                <select name="class_id" id="class_id" class="form-control">
                    <option value="0">Select Class</option>

                    <?php foreach ($allClassList as $row){ ?>
                        <option <?php if(@$_POST['class_id'] == $row['id']) { echo "selected"; }
                        ?>
                                value="<?php
                                echo $row['id'];
                                ?>"><?php
                            echo
                            $row['name']; ?></option>
                    <?php } ?>

                </select>
            </div>
        </div>
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Section:</label>
				<input type="text" class="form-control" id="add_section" name="add_section" value="<?php echo $sectionDetails['name']; ?>">
				<input type="hidden" value="<?php echo $sectionDetails['id']; ?>" id="section_id" name="section_id" />
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademySection()" class="btn btn-primary btn-flat submit-trigger">Update Section</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


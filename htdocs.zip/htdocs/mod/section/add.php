<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$addSection = trim($_POST['add_section']);
        $class_id = $_POST['class_id'];
		$classData = array(
			'name'	=> $addSection,
            'class_id'=> $class_id
		);
		
		 
		 //$dublicateSection = dublicateRecord('section',$addSection);
		
    	/*if($dublicateSection = 0) { */
    	     

        	$addSectionData = prepareInsert('section', $classData);
    		
    		if($addSectionData)
    		{
    			$response['status'] = true;
    			$response['message'] = "<p>Section added Successfully</p>";
    			
    		} else
    		{
    			$response['status'] = false;
    			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
    			
    		}
    
    
    	/*} else {
    	    
    	    $response['status']=false;
    	 $response['message']="<p>This record already exists!</p>";  
    	    
    	}*/
	
	 
	
	 
		echo json_encode($response);
		
		
	}
	
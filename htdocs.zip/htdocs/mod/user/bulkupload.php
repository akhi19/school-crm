<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/17/2018
	 * Time: 11:20 PM
	 */
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	$response = [];
	$fileName = $_FILES["fileToUpload"]["tmp_name"];
	
	
	if ($_FILES["fileToUpload"]["size"] > 0) {
		
		$file = fopen($fileName, "r");
		
		$i = 0;
		while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
			if($i == 1) {
				
				
				$user_data = array(
					'name'	=> $column[0],
					'email'	=> $column[1],
					'username' => $column[3],
					'password' => sha1($column[4]),
					'user_type' =>  $column[5],
					'mobile' => $column[2],
					'active' => 1
				);
				
				prepareInsert('user', $user_data);
				
			}
			$i = 1;
		}
		
		$response['status'] = "success";
		$response['message'] = '<p style="color:#fff">Bulk User data added successfully!</p>';
	} else {
		$response['message'] = '<p style="color:red">Please try again later!</p>';
	}
	
	echo json_encode($response);
 
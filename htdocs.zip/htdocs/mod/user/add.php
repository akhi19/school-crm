<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST)
	{
		$response = [];
		
		$add_user = trim($_POST['add_user']);
		$add_email = trim($_POST['add_email']);
		$add_password = trim(sha1($_POST['add_password']));
		$add_usertype = trim($_POST['add_usertype']);
		$add_username = trim($_POST['add_username']);
		$add_mobile = trim($_POST['add_mobile']);
		
		$userData = array(
			'name'	=> $add_user,
			'email'	=> $add_email,
			'password'	=> $add_password,
			'user_type' => $add_usertype,
			'username' => $add_username,
			'mobile' => $add_mobile,
			'active' => 1
		);
		
		
		$addUserData = prepareInsert('user', $userData);
		
		if($addUserData)
		{
			$response['status'] = true;
			$response['message'] = "<p>User added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
		
		
	}
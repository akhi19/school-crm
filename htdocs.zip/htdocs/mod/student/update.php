<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		 
		$student_id = $_POST['student_id'];
		
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$messg_op = !empty($_POST['messg_op']) ? implode(",",  $_POST['messg_op']) : NUll;
		$father_name = $_POST['father_name'];
		$father_mobile = $_POST['father_mobile'];
		$mother_name = $_POST['mother_name'];
		$mother_mobile = $_POST['mother_mobile'];
		$aadhar_no = $_POST['aadhar_no'];
		$gr_no = $_POST['gr_no'];
		$dob = date("Y-m-d", strtotime($_POST['dob']));
		
		$bus_op = $_POST['bus_op_edit'];
		
		$bus_route_id  =  ($bus_op == 1) ? $_POST['bus_route_id'] : 0;
		$bus_no_id  =  ($bus_op == 1) ? $_POST['bus_no_id'] : 0;
		
		$student_ids = $_POST['student_ids'];
		
	   
		
		$studentData = array(
		    'aadhar_card' => $aadhar_no,
			'gr_no' => $gr_no,
			'dob' => $dob,
			'opt_bus' => $bus_op,
			'bus_no_id' => $bus_no_id,
			'bus_route_id' => $bus_route_id,
			'first_name'	=> $first_name,
			'last_name'	=> $last_name,
			'class_id'	=> $class_id,
			'section_id'	=> $section_id,
			'father_name'	=> $father_name,
			'father_mobile'	=> $father_mobile,
			'mother_name'	=> $mother_name,
			'mother_mobile'	=> $mother_mobile,
			'student_id'	=> $student_ids,
			'opt_message' => $messg_op,
			'updated_at' => date("Y-m-d h:i:s")
		
		);
		
	     
		$updateStudentData = prepareUpdate('student', $studentData, " WHERE id =  $student_id ");
		
		if($updateStudentData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Student updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
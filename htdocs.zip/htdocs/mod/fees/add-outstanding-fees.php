<?php 
        require_once '../../includes/config.php';
        require_once '../../includes/functions.php';
?>
    <?php if($_POST) {  
        $student_id =  $_POST["fees"]["student_id"];
        $outstandingFees =  $_POST["fees"]["outstandingFees"];
		$academic_year = $_POST["fees"]["academic_year"];
        $result = addOutstandingFees($student_id, $outstandingFees,$academic_year);
        if($result == 1)
		{
			$response['status'] = true;
			$response['message'] = "<p>Outstanding fees added Successfully</p>";
			echo json_encode($response);
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			echo json_encode($response);
		}
    }
?>
<?php require_once 'head.php'; ?>

    <div class="wrapper">

<?php require_once 'header.php'; ?>
<?php require_once 'navigation.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <section class="content-header">
            <h1>
                Error
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Dashboard</li>
            </ol>
        </section>


        <section class="content">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-lg-6 col-xs-6">
                    <h3> Page not found!</h3>
    
                    <p>The page you are trying to access does not exist. <br />
                        Please navigate to the <a href="/">home page</a>
                    </p>
                </div>
            </div>
        </section>
       
	    
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php require_once 'sub-footer.php'; ?>

    </div>
    <!-- ./wrapper -->

<?php require_once 'footer.php'; ?>
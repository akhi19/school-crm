<?php
	/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/9/2018
 * Time: 2:38 PM
 */
  if(!empty($_SESSION['sessid'])) {
  	
  	  unset($_SESSION['sessid']);
  	  session_destroy();
	  redirect("/");
  }
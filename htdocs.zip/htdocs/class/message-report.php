<?php
require_once('./includes/functions.php');
if($_SESSION['sessid'] == ''){ redirect('/'); }
//ini_set('memory_limit','16M');
$prod_data = array();
global $conn;
$data = array('ID','Student Name', 'Messages','Class','Section', 'Date');

array_push($prod_data, $data);


extract($_GET);
$i = 0;
$where = " 1=1 ";

if($sid !=0 && $bid !=0 && $cid !=0 && $rid !=0){
    $where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
}else if($sid ==0 && $bid ==0 && $cid ==0 && $rid ==0){
    //$where .= " AND class_id = $cid and section_id = $sid and bus_no_id = $bid and bus_route_id = $rid";
}else {
    if($bid != 0 ){
        $where .= " AND bus_no_id = $bid " ;
    }if($cid !=0 ){
        $where .= " AND class_id = $cid " ;
    }if($sid !=0) {
        $where .= " AND section_id = $sid " ;
    } if($rid !=0) {
        $where .= " AND bus_route_id = $rid " ;
    }
}
$sql = "select * from `message` WHERE {$where}  ORDER BY `id` DESC";
$query = mysqli_query($conn, $sql);

while($row = mysqli_fetch_assoc($query))
{


   $i++;

        array_push($prod_data, array($i,getStudentNameById('student',$row['user_id']),$row['message'], getNameById('class',$row['class_id']),
        getNameById('section',$row['section_id']),$row['created_at']));

}
$temp_memory = fopen('php://memory', 'w');
/** loop through array  */
foreach ($prod_data as $line) {
    /** default php csv handler * */
    fputcsv($temp_memory, $line, ',');
}

/** rewrind the "file" with the csv lines * */
fseek($temp_memory, 0);

/** modify header to be downloadable csv file * */
header('Content-Type: application/csv');

header('Content-Disposition: attachement; filename="student_list.csv"');

/** Send file to browser for download */
fpassthru($temp_memory);
?>

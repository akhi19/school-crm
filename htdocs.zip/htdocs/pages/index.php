<?php
    if(!empty($_SESSION['sessid'])) {
        redirect('/dashboard');
    }
    require_once 'head.php'; ?>

	<div class="login-box">
		<div class="login-logo">
			<a href="index2.html"><b>School</b>CRM</a>
		</div>
		<!-- /.login-logo -->
		<div class="login-box-body">
			<p class="login-box-msg">Sign in to start your session</p>
			<div id="error_response"></div>
			<form  id="login-form"  name="login-form" method="post">
				<div class="form-group has-feedback">
					<input type="text" class="form-control" id="login-username" name="login-username" placeholder="username">
					<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				</div>
				<div class="form-group has-feedback">
					<input type="password" id="login-password" name="login-password" class="form-control" placeholder="Password">
					<span class="glyphicon glyphicon-lock form-control-feedback"></span>
				</div>
				<div class="row">
					
					<!-- /.col -->
					<div class="col-xs-12">
						<button type="submit"  class="btn btn-primary btn-block btn-flat submit-trigger">Sign In</button>
                        <button type="button" style="display: none;"   class="btn btn-primary btn-block btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
					</div>
					<!-- /.col -->
				</div>
			</form>
			
			
		
		</div>
		<!-- /.login-box-body -->
	</div>
	<!-- /.login-box -->
<?php require_once 'footer.php'; ?>
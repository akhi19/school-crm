<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">
	
	<?php require_once 'header.php'; ?>
	<?php require_once 'navigation.php'; ?>
	<?php
		$allClassList = getMultipleRecord('class');
    $allSectionList =$allRouteList= array();
    if(isset($_GET['cid']) && $_GET['cid']>0){
        $allSectionList = getMultipleRecord('section',array('class_id'=>$_GET['cid']));
    }
		$allBusList = getMultipleRecord('bus_number');
    if(isset($_GET['bid']) && $_GET['bid']>0){
        $allRouteList = getMultipleRecord('bus_route',array('busno_id'=>$_GET['bid']));
    }
		
		$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
		if ($page <= 0) $page = 1;
		
		$per_page = 10; // Set how many records do you want to display per page.
		
		$startpoint = ($page * $per_page) - $per_page;
		
		
		$recordCount = "";
		$empty = "";
		if(isset($_GET['cid']) !="" || isset($_GET['sid']) !="" || isset($_GET['bid']) !="" || isset($_GET['rid']) !="") {
			$query = getStudentList($_GET['cid'],$_GET['sid'], $_GET['bid'], $_GET['rid']);
			
			$statement = "`student` WHERE {$query} ORDER BY IF(`first_name` RLIKE '^[a-z]', 1, 2), `first_name`";
			
			$allStudentList = pagingQuery($statement,$startpoint,$per_page);
			
			if(empty($allStudentList)) {
				$empty = 'There are no results matching your searching criteria.';
			}
			$recordCount = count($allStudentList);
		} else {
			$query = "1=1";
			$statement = "`student` WHERE {$query} ORDER BY IF(`first_name` RLIKE '^[a-z]', 1, 2), `first_name`";
			$allStudentList = pagingQuery($statement,$startpoint,$per_page);
			$empty = 'There are currently no records.';
			
			
		}
	
	
	?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Promotion
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"><a href="#">Promotion</a></li>

            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">

                    <div class="box">
                        <div class="box-header">


                            <div class="col-md-4 pl0">
                                <div class="pull-left">
                                  
                                    <a href="javascript:void(0)" class="btn btn-info promoteStudent" >
                                        <i class="fa fa-users"></i> Promote Student</a>

                                    

                                </div>

                            </div>
                            <div class="col-md-8">
                                <div class="pull-right">
                                    <div class="col-md-3">
                                        <select name="filterpromotionclass" id="filterpromotionclass"
                                                class="form-control">
                                            <option value="0">Select Class</option>
											
											<?php foreach ($allClassList as $row){ ?>
                                                <option <?php if(@$_GET['cid'] == $row['id']) { echo "selected"; }
												?>
                                                        value="<?php
															echo $row['id'];
														?>"><?php
														echo
														$row['name']; ?></option>
											<?php } ?>

                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <select name="filterpromotionsection" id="filterpromotionsection" class="form-control">
                                            <option value="0">Select Division</option>
											
											<?php foreach ($allSectionList as $row){ ?>
                                                <option <?php if( @$_GET['sid'] == $row['id']) { echo "selected"; }
												?>  value="<?php echo $row['id']; ?>"><?php echo
													$row['name']; ?></option>
											<?php } ?>

                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <select name="filterpromotionBusno" id="filterpromotionBusno" class="form-control">
                                            <option value="0">Select Bus No</option>
			
			                                <?php foreach ($allBusList as $row){ ?>
                                                <option <?php if( @$_GET['bid'] == $row['id']) { echo "selected"; }
				                                ?>  value="<?php echo $row['id']; ?>"><?php echo
					                                $row['name']; ?></option>
			                                <?php } ?>

                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <select name="filterpromotionBusroute" id="filterpromotionBusroute" class="form-control">
                                            <option value="0">Select Bus Route</option>
			
			                                <?php foreach ($allRouteList as $row){ ?>
                                                <option <?php if( @$_GET['rid'] == $row['id']) { echo "selected"; }
				                                ?>  value="<?php echo $row['id']; ?>"><?php echo
					                                $row['name']; ?></option>
			                                <?php } ?>

                                        </select>
                                    </div>

                                </div>
                            </div>


                        </div>

                        <!-- /.box-header -->
                        <div class="box-body">

                            <div id="error-promoteStudent"></div>
                            <div id="update-response"></div>
                            <div class="row" id="promoteStudents" style="display:none;background:  #e7e7e7;padding:
                            20px;
                            ">
                                <div class="col-md-3">
                                    <select name="promoteClass" id="promoteClass" class="form-control">
                                        <option value="">Select Class</option>

                                        <?php foreach ($allClassList as $row){ ?>
                                            <option
                                                    value="<?php
                                                    echo $row['id'];
                                                    ?>"><?php
                                                echo
                                                $row['name']; ?></option>
                                        <?php } ?>

                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <select name="promoteSection" id="promoteSection" class="promoteSection form-control">
                                        <option value="">Select Division</option>

                                        <?php /*foreach ($allSectionList as $row){ */?><!--
                                            <option <?php /*if( @$_GET['sid'] == $row['id']) { echo "selected"; }
                                            */?>  value="<?php /*echo $row['id']; */?>"><?php /*echo
                                                $row['name']; */?></option>
                                        --><?php /*} */?>

                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <input type="text" name="promotionAcademicYear" id="promotionAcademicYear" class="promoteSection form-control" placeholder="Academic Year" >
                                </div>

                                <div class="col-md-3">
                                   
                                    <button type="button"  onclick="updatePromotion()" class="btn btn-primary
                                    btn-flat submit-trigger">Promote Student</button>
                                    <button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
                                </div>


                            </div>
	
	                        <?php if(!empty($allStudentList)) { ?>
                            <table  class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th><input type="checkbox" id="checkAll"></th>
                                    <th>Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Class</th>
                                    <th>Division</th>
                                    <th>Created Date</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>
								
									<?php $i = 0; foreach($allStudentList as $row) { $i++; ?>
                                        <tr>
                                            <td> <input type="checkbox" name="promoteStudent" value="<?php echo
												$row['id']; ?>"
                                                        class="promoteStudent"> </td>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['first_name']; ?> </td>
                                            <td><?php echo $row['last_name']; ?> </td>
                                            <td><?php echo getNameById('class',$row['class_id']); ?> </td>
                                            <td><?php echo getNameById('section',$row['section_id']); ?> </td>
                                            <td><?php echo $row['created_at']; ?></td>
                                            <td>




                                                <a href="javascript:void(0)" id="<?php echo $row['id']; ?>"
                                                   class="btn btn-warning btn-xs mrg" data-placement="top"
                                                   data-toggle="modal" data-target="#editStudent"
                                                   data-original-title="Edit"><i class="fa fa-edit"></i></a>
												<?php if( $_SESSION['sessUser'] == 'admin') { ?>
                                                    <a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>" class="btn btn-danger btn-xs mrg delete_student" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
												<?php } ?>
                                            </td>

                                        </tr>
									<?php } ?>


                                </tbody>
                                <tfoot>

                                </tfoot>
                            </table>
                            
                            <?php echo  pagination($statement,$per_page,$page,$url='?', $recordCount); ?>
							<?php } else { ?>
                                <div class="alert alert-danger">
                                    <strong>Error!</strong> <?php echo $empty; ?>
                                </div>
							
							
							<?php }	?>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- modal class start --->
 

    
	
	
	<?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

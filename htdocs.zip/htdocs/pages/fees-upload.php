<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">
	
	<?php require_once 'header.php'; ?>
	<?php require_once 'navigation.php';
    $allClassList = getMultipleRecord('class');
	?>
	
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
                Fees Upload
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active"><a href="#">Class Fees</a></li>
				
			</ol>
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-xs-12">
			 
					<div class="box">
						<div class="box-header">
							<h6 class="page-header">
							 
								<a id="" class="btn btn-primary" data-toggle="modal" data-target="#addFees">
									+ Add Class Fees</a>
							</h6>
						</div>
					 
						 <!-- /.box-header -->
						<div class="box-body">
							<table id="class-table" class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Id</th>
                                    <th>Class</th>
									<th>Academic Year</th>
									<th>Tuition Fees</th>
									<th>Development Fees</th>
									<th>Term Fees</th>
									<th>Computer Fees</th>
									<th>Total</th>
									<th>Created Date</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php
									$allSectionList = getWithoutSortRecord('class_fees');
								?>
								<?php if(!empty($allSectionList)) { ?>
								<?php $i = 0; foreach($allSectionList as $row) { $i++; ?>
									<tr>
										<td><?php echo $i; ?></td>
                                        <td><?php echo $row['class']; ?> </td>
										<td><?php echo $row['academic_year']; ?> </td>
										<td><?php echo $row['tuition_fees']; ?> </td>
										<td><?php echo $row['development_fees']; ?> </td>
										<td><?php echo $row['term_fees']; ?> </td>
										<td><?php echo $row['computer_fees']; ?> </td>
										<td><?php echo $row['total_fees']; ?> </td>
										<td><?php echo $row['created_at']; ?></td>
										<td>
											<a href="javascript:void(0)" id="<?php echo $row['id']; ?>" data-class="<?php echo $row['class']; ?>" class="btn btn-warning btn-xs mrg" data-placement="top" data-toggle="modal" data-target="#editClassFees" data-original-title="Edit"><i class="fa fa-edit"></i></a>
									        <?php if( $_SESSION['sessUser'] == 'admin') { ?>
											    <a href="javascript:void(0)" data-class="<?php echo $row['class']; ?>" data-year="<?php echo $row['academic_year']; ?>" class="btn btn-danger btn-xs mrg delete_class_fees" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
								<?php } ?>
							 
							 
								</tbody>
								<tfoot>
						 
								</tfoot>
							</table>
						</div>
						<!-- /.box-body -->
					</div>
					<!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	<!-- modal class start --->
	
	<!-- Modal -->
	<div id="addFees" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Fees</h4>
				</div>
				<div class="modal-body">
					<div id="response"></div>
					<form id="add_fees_form" class="add_fees_form">
						<div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="text">Class:</label>
                                    <select name="class_id" id="class_id" class="form-control">
                                        <option value="0">Select Class</option>

                                        <?php foreach ($allClassList as $row){ ?>
                                            <option value="<?php echo $row['name'];?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>

                                    </select>
                                </div>
                            </div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Academic Year:</label>
									<input type="text" class="form-control" id="academic_year" name="academic_year" placeholder="Academic Year">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Tuition Fees:</label>
									<input type="text" class="form-control" id="tuition_fees" name="tuition_fees" placeholder="Tuition Fees">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Development Fees:</label>
									<input type="text" class="form-control" id="development_fees" name="development_fees" placeholder="Development Fees">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Term Fees:</label>
									<input type="text" class="form-control" id="term_fees" name="term_fees" placeholder="Term Fees">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Computer Fees:</label>
									<input type="text" class="form-control" id="computer_fees" name="computer_fees" placeholder="Computer Fees">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Total Fees:</label>
									<input type="text" class="form-control" id="total_fees" name="total_fees" placeholder="Total Fees">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<button type="button"  onclick="addAcademyFees()" class="btn btn-primary btn-flat submit-trigger">Add Fees</button>
									<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
								
								</div>
							</div>
						
						</div>
					
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal class end --->
	
	
	<!-- modal edit class start --->
	
	<!-- Modal -->
	<div id="editClassFees" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Edit Class Fees</h4>
				</div>
				<div class="modal-body">
					<div id="update-response"></div>
					<div id="user_data"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal edit class end --->
	
	<!-- modal delete class start -->
	
	<!-- modal box for delte confirmation start --->
	<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Confirm</h4>
				</div>
				<div class="modal-body">
					<p><strong>Do you really want to delete this record ?</strong></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- end -->
	<!-- modal box for delte confirmation end ---->
	
	<!-- modal delete class end --->
	
	
	
	 <?php require_once 'sub-footer.php'; ?>
	
	 
</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

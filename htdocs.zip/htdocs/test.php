<?php
date_default_timezone_set('Asia/Kolkata');
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://eu7.chat-api.com/instance5469/showMessagesQueue?token=d84laii298pl228r",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => "",
    CURLOPT_HTTPHEADER => array(
        "Content-Type: application/x-www-form-urlencoded",
        "Postman-Token: 27160f09-9ee4-42b1-abc2-d63f66176634",
        "cache-control: no-cache",
        "header: Content-type: application/json"
    ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);
echo "<pre>";
if ($err) {
    die( "cURL Error #:" . $err);
} else {
    $response = json_decode($response,true);
    //var_dump($response);

   function epoch2time($epoch){
       //$dt = new DateTime("@$epoch");  // convert UNIX timestamp to PHP DateTime
       return date("d/m/Y H:i:s A", substr($epoch, 0, 10));
       //return $dt->format('Y-m-d H:i:s A');
   }
   $i=1;
    $totalmsg = $response['totalMessages'];
   $first100 = $response['first100'];
   echo "<table border='1' style='width:100%;'><tr><th colspan='3'>Total Message</th><th colspan='3'>$totalmsg</th></tr>";
    echo "<tr><th colspan='6'>First 100 Message</th></tr>";
   echo "<tr><th>Sr. No</th><th>id</th><th style='width:65%;'>body</th><th>type</th><th>chatId</th><th>last_try</th></tr>";
   foreach ($first100 as $record){
       echo "<tr><td>".$i++."</td><td>".$record['id']."</td><td>".$record['body']."</td><td>".$record['type']."</td><td>".$record['chatId']."</td><td>".epoch2time($record['last_try'])."</td></tr>";
   }
   echo "</table>";
}
<?php  if($_SESSION['sessid'] == ''){ redirect('/'); } ?>
<?php require_once 'head.php'; ?>
<div class="wrapper">
	
	<?php require_once 'header.php'; ?>
	<?php require_once 'navigation.php'; ?>
	
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				Bus
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active"><a href="#">Bus</a></li>
			
			</ol>
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-xs-12">
					
					<div class="box">
						<div class="box-header">
							<h6 class="page-header">
								
								<a id="" class="btn btn-primary" data-toggle="modal" data-target="#addBus">
									+ Add New Bus</a>
							</h6>
						</div>
						
						<!-- /.box-header -->
						<div class="box-body">
							<table id="class-table" class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Id</th>
									<th>Bus Route</th>
									<th>Bus Area</th>
									<th>Created Date</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php
									$allBusList = getMultipleRecord('bus');
								?>
								<?php if(!empty($allBusList)) { ?>
									<?php $i = 0; foreach($allBusList as $row) { $i++; ?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['bus_no']; ?> </td>
											<td><?php echo $row['bus_area']; ?> </td>
											<td><?php echo $row['created_at']; ?></td>
											<td>
												<a href="javascript:void(0)" id="<?php echo $row['id']; ?>"
												   class="btn btn-warning btn-xs mrg" data-placement="top"
												   data-toggle="modal" data-target="#editBus"
												   data-original-title="Edit"><i class="fa fa-edit"></i></a>
												<?php if( $_SESSION['sessUser'] == 'admin') { ?>
													<a href="javascript:void(0)" data-id="<?php echo $row['id']; ?>"
													   class="btn btn-danger btn-xs mrg delete_bus"
													   data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
												<?php } ?>
											</td>
										</tr>
									<?php } ?>
								<?php } ?>
								
								
								</tbody>
								<tfoot>
								
								</tfoot>
							</table>
						</div>
						<!-- /.box-body -->
					</div>
					<!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	<!-- modal class start --->
	
	<!-- Modal -->
	<div id="addBus" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Bus</h4>
				</div>
				<div class="modal-body">
					<div id="response_bus"></div>
					<form id="bus_form" class="bus_form">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="text">Bus Route:</label>
									<input type="text" class="form-control" id="add_bus_no" name="add_bus_no"
									       placeholder="Enter Bus No">
								</div>
								
								
								<div class="form-group">
									<label for="text">Bus Area:</label>
									<input type="text" class="form-control" id="add_bus_area" name="add_bus_area"
									       placeholder="Enter Bus Area">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<button type="button"  onclick="addAcademyBus()" class="btn btn-primary btn-flat
									submit-trigger">Add Bus</button>
									<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
								
								</div>
							</div>
						
						</div>
					
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal class end --->
	
	
	<!-- modal edit class start --->
	
	<!-- Modal -->
	<div id="editBus" class="modal fade" role="dialog">
		<div class="modal-dialog">
			
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Edit Bus</h4>
				</div>
				<div class="modal-body">
					<div id="update-response"></div>
					<div id="user_data"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- modal edit class end --->
	
	<!-- modal delete class start -->
	
	<!-- modal box for delte confirmation start --->
	<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Confirm</h4>
				</div>
				<div class="modal-body">
					<p><strong>Do you really want to delete this record ?</strong></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-danger" id="btn_confirmed_delete">Delete</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- end -->
	<!-- modal box for delte confirmation end ---->
	
	<!-- modal delete class end --->
	
	
	
	<?php require_once 'sub-footer.php'; ?>


</div>
<!-- ./wrapper -->
<?php require_once 'footer.php'; ?>

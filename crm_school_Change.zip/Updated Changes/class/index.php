<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/8/2018
	 * Time: 9:46 PM
	 */
	defined("SITE_IS_LIVE")
		|| define("SITE_IS_LIVE", false);
	
	require_once '../includes/config.php';
	require_once '../includes/functions.php';
	
	getPage();
	
	
<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:37 AM
	 */

	defined("DB_HOST")
	|| define("DB_HOST", "localhost");
	defined("DB_NAME")
	|| define("DB_NAME", "expertsschool_crn");
	defined("DB_USERNAME")
	|| define("DB_USERNAME", "expertsschool_crn");
	defined("DB_PASSWORD")
	|| define("DB_PASSWORD", "latest@123");
	
	// Create connection
	$conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
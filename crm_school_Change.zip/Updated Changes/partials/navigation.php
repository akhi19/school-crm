<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo ucfirst($_SESSION['username']); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <?php
        $bothuser = array('admin','user');
        $singleuser = array('admin');
        ?>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">

            <?php if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                <li <?php echo activeClass('dashboard'); ?>>
                    <a href="/dashboard">
                        <i class="fa fa-th"></i> <span>Dashboards</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>

            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                <li <?php echo activeClass('class'); ?>>
                    <a href="/class">
                        <i class="fa fa-sitemap"></i> <span>Class</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>

                <li <?php echo activeClass('section'); ?>>
                    <a href="/section" >
                        <i class="fa fa-star"></i> <span>Division</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                <li <?php echo activeClass('contact'); ?>>
                    <a href="/contact">
                        <i class="fa fa-user"></i> <span>Contact</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                <li <?php echo activeClass('user'); ?>>
                    <a href="/user">
                        <i class="fa fa-user"></i> <span>User</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>

                <li <?php echo activeClass('student'); ?>>
                    <a href="/student">
                        <i class="fa fa-user"></i> <span>Student</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                <li <?php echo activeClass('promotion'); ?>>
                    <a href="/promotion">
                        <i class="fa fa-user"></i> <span>Promotion</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>
                <li <?php echo activeClass('messages'); ?>>
                    <a href="/messages">
                        <i class="fa fa-envelope"></i> <span>Message</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>

            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>
                <li <?php echo activeClass('bus-number'); ?>>
                    <a href="/bus-number">
                        <i class="fa fa-bus"></i> <span>Bus Number</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php } if(in_array($_SESSION['sessUser'],$singleuser)){ ?>

                <li <?php echo activeClass('bus-route'); ?>>
                    <a href="/bus-route">
                        <i class="fa fa-bus"></i> <span>Bus Route</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>

            <?php } if(in_array($_SESSION['sessUser'],$bothuser)){ ?>

<li>
    <a href="/fees">
        <i class="fa fa-money"></i> <span>Fees Payment</span>
        <span class="pull-right-container">
</span>
    </a>
</li>
<?php }      if(in_array($_SESSION['sessUser'],$bothuser)){ ?>

                <li>
                    <a href="/logout">
                        <i class="fa fa-sign-out"></i> <span>Logout</span>
                        <span class="pull-right-container">
            </span>
                    </a>
                </li>
            <?php }  ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

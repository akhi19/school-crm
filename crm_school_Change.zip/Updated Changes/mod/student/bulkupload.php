<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/17/2018
	 * Time: 11:20 PM
	 */
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	$response = [];
	$fileName = $_FILES["studentFileToUpload"]["tmp_name"];
	
	
	if ($_FILES["studentFileToUpload"]["size"] > 0) {
		
		$file = fopen($fileName, "r");
		
		$i = 0;
		while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
			if($i == 1) {
				
				try {
					
					$classId = getIdByValue('class',trim($column[8]));
					$sectionId = getIdByValue('section',trim($column[9]));
					
						if($classid > 0 && $sectionid > 0) {
							
							$student_data = array(
								'aadhar_card'	=> $column[0],
								'student_id'	=> $column[1],
								'gr_no' => $column[2],
								'dob' => date("Y-m-d", strtotime($column[3])),
								'opt_bus' =>  $column[4],
								'bus_details' => $column[5],
								'first_name'	=> $column[6],
								'last_name'	=> $column[7],
								'class_id' => $classId,
								'section_id' => $sectionId,
								'father_name' =>  $column[10],
								'father_mobile' => $column[11],
								'mother_name' => $column[12],
								'mother_mobile' => $column[13],
								'active' => 1
							);
							
							prepareInsert('student', $student_data);
						
						} else {
							$response['status'] = "error";
							$response['message'] = '<p style="color:white">Class/Division Not Found!</p>';
							echo json_encode($response);
							return;
						}
					
					
						
				
			}
				catch(Exception $e) {
						$response['status'] = "error";
						$response['message'] = '<p style="color:white">Error in import file!</p>';
						echo json_encode($response);
						return;
					}
				
			}
			$i = 1;
		}
		
		$response['status'] = "success";
		$response['message'] = '<p style="color:#fff">Bulk User data added successfully!</p>';
	} else {
		$response['message'] = '<p style="color:red">Please try again later!</p>';
	}
	
	echo json_encode($response);
 
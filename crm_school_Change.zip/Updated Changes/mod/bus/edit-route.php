<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
    $busno_id = $_POST['busno_id'];
	if($_POST){
        $allBusList = getMultipleRecord('bus_number');
		$busrouteDetails = getSingleRecord('bus_route', $id);
	}
?>

<form id="update_busroute_form" class="update_busroute_form">
	<div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="text">Bus Route:</label>
                <select name="busno_id" id="busno_id" class="form-control">
                    <option value="0">Select Bus Route</option>

                    <?php foreach ($allBusList as $row){ ?>
                        <option <?php if(@$_POST['busno_id'] == $row['id']) { echo "selected"; }
                        ?>
                                value="<?php
                                echo $row['id'];
                                ?>"><?php
                            echo
                            $row['name']; ?></option>
                    <?php } ?>

                </select>
            </div>
        </div>
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Bus Route:</label>
				<input type="text" class="form-control" id="add_busroute" name="add_busroute" value="<?php echo $busrouteDetails['name']; ?>">
				<input type="hidden" value="<?php echo $busrouteDetails['id']; ?>" id="busroute_id" name="busroute_id" />
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademyBusroute()" class="btn btn-primary btn-flat
				submit-trigger">Update Bus Route</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


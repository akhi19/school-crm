<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
	if($_POST){
		$busnumberDetails = getSingleRecord('bus_number', $id);
	}
?>

<form id="update_busnumber_form" class="update_busnumber_form">
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Bus Number:</label>
				<input type="text" class="form-control" id="add_busnumber" name="add_busnumber" value="<?php echo
				$busnumberDetails['name']; ?>">
				<input type="hidden" value="<?php echo $busnumberDetails['id']; ?>" id="busnumber_id"
				       name="busnumber_id" />
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademyBusnumber()" class="btn btn-primary btn-flat
				submit-trigger">Update Bus Number</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


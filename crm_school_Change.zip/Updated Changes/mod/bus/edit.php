<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
	if($_POST){
		$busDetails = getSingleRecord('bus', $id);
	}
?>

<form id="update_bus_form" class="update_bus_form">
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Bus No:</label>
				<input type="text" class="form-control" id="add_bus_no" name="add_bus_no"
				       value="<?php echo $busDetails['bus_no']; ?>">
				
				<input type="hidden" value="<?php echo $busDetails['id']; ?>" id="bus_id" name="bus_id" />
			</div>
			
			<div class="form-group">
				<label for="text">Bus Area:</label>
				<input type="text" class="form-control" id="add_bus_area" name="add_bus_area"
				       value="<?php echo $busDetails['bus_area']; ?>">
	 
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademyBus()" class="btn btn-primary btn-flat
				submit-trigger">Update Bus</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		
		$busnumber_id = $_POST['id'];
		
		
		$deleteBusnumberData = prepareDelete('bus_number', $busnumber_id);
		
		if($deleteBusnumberData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Number deleted Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
<?php
/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/9/2018
 * Time: 8:01 AM
 */

require_once '../../includes/config.php';
require_once '../../includes/functions.php';
$busno_id = $_POST['busno_id'];
if(@$_POST['busno_id']>0){
    $allRouteList = getMultipleRecord('bus_route',array('busno_id'=>$_POST['busno_id']));
}
?>

<option value="0">Please Select Bus Route</option>
<?php foreach ($allRouteList as $row){ ?>
    <option value="<?php echo $row['id'];?>"><?php echo $row['name']; ?></option>
<?php } ?>



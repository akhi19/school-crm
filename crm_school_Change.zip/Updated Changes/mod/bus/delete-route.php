<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		
		$busroute_id = $_POST['id'];
		
		
		$deleteBusrouteData = prepareDelete('bus_route', $busroute_id);
		
		if($deleteBusrouteData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Bus Route deleted Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
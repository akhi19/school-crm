<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../includes/config.php';
	require_once '../includes/functions.php';
	
	if($_POST)
	{
		$response = [];
		
		$loginUsername = $_POST['login-username'];
		$loginPassword = sha1($_POST['login-password']);
		 
		$userLogin = userLogin($loginUsername, $loginPassword);
		
		if($userLogin > 0) {
			
			$_SESSION['sessid'] = $userLogin['id'];
			$_SESSION['username'] = $userLogin['name'];
			$_SESSION['sessUser'] = $userLogin['user_type'];
			$response['status'] = true;
			$response['message'] = "<p>Login successfull! Pls wait...</p>";
			$response['url'] = "/dashboard";
			
		} else {
			
			 
				$response['status'] = false;
				$response['message'] = "<p>Wrong username / password !</p>";
			 
		}
		
		
		
		echo json_encode($response);
		
		
	}
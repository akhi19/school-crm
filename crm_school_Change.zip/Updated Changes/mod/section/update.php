<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		
		$add_section = $_POST['add_section'];
		$section_id = $_POST['section_id'];
        $class_id = $_POST['class_id'];
		
		$sectionData = array(
			'name'	=> $add_section,
			'class_id'=> $class_id,
			'updated_at' => date("Y-m-d h:i:s")
			
		);
		
		
		$updateSectionData = prepareUpdate('section', $sectionData, " WHERE id =  $section_id ");
		
		if($updateSectionData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Section updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
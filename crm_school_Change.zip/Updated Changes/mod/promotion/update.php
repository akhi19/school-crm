<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	
	if($_POST){
		$response = [];
 
		$student_class = $_POST['class'];
		$student_section = $_POST['division'];
		$student_id = $_POST['studentIds'];
		$academic_year = $_POST['academic_year'];
		
		foreach ($student_id as $id) {
			// $studentData = array(
			// 	'class_id'	=> $student_class,
			// 	'section_id'	=> $student_section,
			// 	'updated_at' => date("Y-m-d h:i:s"),
			// 	'academic_year' => $academic_year		
			// );
		  $studentDetails = getSingleRecord('student',$id);
		   $result = promoteStudent($id,$studentDetails['gr_no'],$student_class, $student_section,date("Y-m-d h:i:s"),$academic_year);
		}
		
		$updateStudentData = 1;
		
		
		if($updateStudentData == 1)
		{
			$response['status'] = true;
			$response['message'] = "<p>Student promoted updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
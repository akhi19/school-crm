<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
	if($_POST){
		$userDetails = getSingleRecord('user', $id);
	}
?>

<form id="update_user_form" class="update_user_form">
	<div class="row">
		<div class="col-md-12">
		    
		    <div class="form-group">
					<label for="text">User Type:</label>
					<select class="form-control" id="add_usertype" name="add_usertype"> 
                        <option value="admin" <?php if($userDetails['user_type'] == 'admin') { echo "selected"; } ?> >Admin</option>
                        <option value="user" <?php if($userDetails['user_type'] == 'user') { echo "selected"; } ?> >User</option> 
                      </select>

				</div>
		    
            <div class="form-group">
                <label for="text">Name:</label>
                <input type="text" class="form-control" id="add_user" name="add_user"
                       value="<?php echo $userDetails['name']; ?>">
            </div>

            <div class="form-group">
                <label for="text">Email:</label>
                <input type="text" class="form-control" id="add_email" name="add_email"
                       value="<?php echo $userDetails['email']; ?>">
            </div>

            <div class="form-group">
                <label for="text">Mobile:</label>
                <input type="text" class="form-control" id="add_mobile" name="add_mobile"
                       value="<?php echo $userDetails['mobile']; ?>">
            </div>
            
            <div class="form-group">
					<label for="text">Uesrname:</label>
					<input type="text" class="form-control" id="add_username" name="add_username"
					       value="<?php echo $userDetails['username']; ?>">
				</div>

            <div class="form-group">
                <label for="text">Password:</label>
                <input type="text" class="form-control" id="add_password" name="add_password" value="">
            </div>
            
            
				
            
		</div>

        <input type="hidden" value="<?php echo $userDetails['id']; ?>" id="user_id" name="user_id" />
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademyUser()" class="btn btn-primary btn-flat
				submit-trigger">Update User</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


<?php
/**
 * Created by PhpStorm.
 * User: HP-Laptop
 * Date: 6/9/2018
 * Time: 1:59 AM
 */

require_once '../../includes/config.php';
require_once '../../includes/functions.php';



if($_POST)
{
    $response = [];
    $uploadOk = 1;
    $message = $_POST['message'];
    $user_id = rtrim($_POST['user_id'], ",");
    $temp = explode(".",$_FILES["sendFile"]["name"]);
    $sendFile = $imageurl='';
    /*if(!empty($_FILES["sendFile"]["name"])){
        //$sendFile = rand(1,99999) . '.' .end($temp);
        $sendFile = $_FILES["sendFile"]["name"];
        $check = getimagesize($_FILES["sendFile"]["tmp_name"]);
        $imgcode = base64_encode(file_get_contents( $_FILES["sendFile"]["tmp_name"] ));
        $img64 = "data:".$check["mime"].";base64,".$imgcode;
        $message1 = $message1."  ".$img64;
    }*/
    if(!empty($_FILES["sendFile"]["name"])){
        $doc_root = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME'])."/uploads/";
        $dir = date('dmY');
        $updir = $doc_root.$dir;
        if(!file_exists($updir)){
            mkdir($updir);
        }
        $sendFile = basename($_FILES["sendFile"]["name"]);
        $imageFileType = strtolower(pathinfo($sendFile,PATHINFO_EXTENSION));
        $sendFile=uniqid().".".$imageFileType;

        if (!move_uploaded_file($_FILES["sendFile"]["tmp_name"],$updir."/". $sendFile)) {
            $uploadOk = 0;
            $response['status'] = 133;
            $response['message'] = "<p>File not uploaded. Please try again later!</p>";
        }else
        {
            $imageurl = url()."/uploads/".$dir."/".$sendFile;
        }
    }

    if($uploadOk == 1){
        $userDetails = getUserDetails($user_id);


        $result = array();
        foreach ($userDetails as $value)
        {

            $messageData = array(
                'user_id' => $user_id,
                'message'=> $message,
                'send_file' => $imageurl
            );

            //send message from whatsapp start

            //print_r($messageData); exit();

            $result[] = sendWhatsappmessage($value['mobile'],$message,$sendFile,$imageurl);

            prepareInsert('message', $messageData);


        }

        if(in_array(0,$result) && in_array(1,$result) )
        {

            $response['status'] = true;
            $response['message'] = "<p>Whatsapp Message Send to some Successfully</p>";


        } else if(in_array(0,$result))
        {
            $response['status'] = 133;
            $response['message'] = "<p>Some problem occured. Please try again later!</p>";

        }else{
            $response['status'] = true;
            $response['message'] = "<p>Whatsapp Message Send to all Successfully</p>";
        }
    }


    echo json_encode($response);
    //send message from whatsapp end


}
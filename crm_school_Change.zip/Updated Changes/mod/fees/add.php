<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
 
	
	if($_POST)
	{
		$response = [];
        
        $gr_no = trim($_POST['add_fees_gr_no']);
		$first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $outstanding_fees = trim($_POST['outstanding_fees']);
		$present_class = trim($_POST['present_class']);
        $fees_from_month = trim($_POST['fees_month']);
        $academic_year = trim($_POST['academic_year']);
		
		$feesData = array(
			'gr_no' => $gr_no,
			// 'first_name'	=> $first_name,
			// 'last_name'	=> $last_name,
			'class'	=> $present_class,
            'outstanding_fees' => $outstanding_fees,
            'fees_months' => $fees_from_month,
            'academic_year' => $academic_year
		);
		
		
		$addFeesData = prepareInsert('student_pending_fees', $feesData);
        
		if($addFeesData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Fees for student added Successfully</p>";
			
		} else
		{
			$response['status'] = false;
            $response['message'] = "<p>Some problem occured. Please try again later!</p>";
		}
		
		echo json_encode($response);
		
		
	}
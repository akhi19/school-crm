<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';


if($_POST)
{
	$id = $_POST['aadhar_no'];
	$empty = "There are no results matching your searching criteria.";
    $allStudentList = getStudentByAadhar($id);

}?>


                            <?php if(!empty($allStudentList)) { ?>
                                <table  class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Class</th>
                                        <th>Division</th>
										<th>GR No.</th>
										<th>Father Mobile No.</th>
										<th>Mother Mobile No.</th>
                                        <th>Action</th>

                                    </tr>
                                    </thead>

                                    <?php $i = 0; foreach($allStudentList as $row) { $i++;?>
									<tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['first_name']; ?> </td>
                                            <td><?php echo $row['last_name']; ?> </td>
                                            <td><?php echo getNameById('class',$row['class_id']); ?> </td>
                                            <td><?php echo getNameById('section',$row['section_id']); ?> </td>
											<td><?php echo $row['gr_no']; ?> </td>
											<td><?php echo $row['father_mobile']; ?> </td>
											<td><?php echo $row['mother_mobile']; ?> </td>
                                                <td>

                                                    <button type="submit" id="<?php echo $row['id']; ?>"
                                                    onclick="getColumnValue(this);"
                                                       class="btn btn-warning btn-xs mrg" data-placement="top"
                                                       data-original-title="Edit"><i class="fa fa-credit-card "></i></button>
                                                </td>

                                        </tr>
                                    <?php } ?>
									
						
						
                                </table>
                            <?php } else { ?>
                                <div class="alert alert-danger">
                                    <strong>Error!</strong> <?php echo $empty; ?>
                                </div>


   <?php }	?>					
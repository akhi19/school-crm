<?php 
        require_once '../../includes/config.php';
        require_once '../../includes/functions.php';
?>
    <?php if($_POST) {  
        $feesRow = json_decode($_POST['fees'], true) ; 
        foreach ($feesRow as $row) {
            $result = insertIntoFeesPayment($row["gr_no"], $row["class"], $row["academic_year"], $row["month"], "txn12345", $row["fees"],"" , $row["mode"], "admin");
            if($result == 0)
            {
                $response['status'] = false;
                $response['message'] = "<p>Some problem occured. Please try again later!</p>";
                echo json_encode($response);
                return;         
            }
        }
        deletePaidFees($row["gr_no"]);
		$response['status'] = true;
        $response['message'] = "<p>Fees payment details updated Successfully</p>";
        echo json_encode($response);
    }
    ?>
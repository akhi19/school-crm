<?php 
        require_once '../../includes/config.php';
        require_once '../../includes/functions.php';
?>
    <?php if($_POST) {  
        $gr_no =  $_POST["fees"]["gr_no"];
        $updatedFees =  $_POST["fees"]["updatedFees"];
        $result = updateOutStandingFees($gr_no, $updatedFees);
        if($result == 1)
		{
			$response['status'] = true;
			$response['message'] = "<p>Outstanding fees updated Successfully</p>";
			echo json_encode($response);
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			echo json_encode($response);
		}
    }
?>
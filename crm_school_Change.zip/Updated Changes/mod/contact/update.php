<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 9:04 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	
	if($_POST){
		$response = [];
		 
		$id = $_POST['id'];
		
		$name = $_POST['name'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
        $country_code = $_POST['country_code'];
        $source = $_POST['source'];

		
	   
		
		$studentData = array(
		    'name' => $name,
			'email' => $email,
			'mobile_no' => $mobile,
			'country_code' => $country_code,
			'source' => $source,
			'updated_at' => date("Y-m-d h:i:s")
		
		);
		
	     
		$updateStudentData = prepareUpdate('contact', $studentData, " WHERE id =  $id ");
		
		if($updateStudentData)
		{
			$response['status'] = true;
			$response['message'] = "<p>Contact updated Successfully</p>";
			
		} else
		{
			$response['status'] = false;
			$response['message'] = "<p>Some problem occured. Please try again later!</p>";
			
		}
		
		echo json_encode($response);
	}
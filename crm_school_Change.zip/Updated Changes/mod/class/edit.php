<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 8:01 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	$id = $_POST['id'];
	if($_POST){
		$classDetails = getSingleRecord('class', $id);
	}
?>

<form id="update_class_form" class="update_class_form">
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<label for="text">Class:</label>
				<input type="text" class="form-control" id="add_class" name="add_class" value="<?php echo $classDetails['name']; ?>">
				<input type="hidden" value="<?php echo $classDetails['id']; ?>" id="class_id" name="class_id" />
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<button type="button"  onclick="editAcademyClass()" class="btn btn-primary btn-flat submit-trigger">Update Class</button>
				<button type="button" style="display: none;"   class="btn btn-primary  btn-flat submit-process"><i class="fa fa-spinner fa-spin" ></i> Process...</button>
			
			</div>
		</div>
	
	</div>

</form>


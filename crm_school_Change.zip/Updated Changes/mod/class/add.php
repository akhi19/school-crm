<?php
	/**
	 * Created by PhpStorm.
	 * User: HP-Laptop
	 * Date: 6/9/2018
	 * Time: 1:59 AM
	 */
	
	require_once '../../includes/config.php';
	require_once '../../includes/functions.php';
	

	if($_POST)
	{
		$response = [];
		
		$addClass = trim($_POST['add_class']);
		
		$classData = array(
			'name'	=> $addClass
		);
		 
		$dublicateClass = dublicateRecord('class', $addClass);
		
	//	echo $dublicateClass; exit();
		
	    if($dublicateClass == 0) {
			
			$addClassData = prepareInsert('class', $classData);
		
			if($addClassData)
			{
				$response['status'] = true;
				$response['message'] = "<p>Class added Successfully</p>";
				
			} else
			{
				$response['status'] = false;
				$response['message'] = "<p>Some problem occured. Please try again later!</p>";
				
			}
			 
		}else {
	
		    $response['status'] = false;
			$response['message'] = "<p>This record already exists!</p>";

		}		
		
		
		
		
		echo json_encode($response);
		
		
	}
<?php
echo 'file_get_contents: ', file_get_contents(__FILE__) ? 'Enabled <br>' : 'Disabled<br>';
$data1 = [
        'phone' => '918097548250', // Receivers phone
        'body' => 'test by developer'  // Message
    ];
    $requesttype = "message";

    //print_r($data); exit();
    $json1 = json_encode($data1); // Encode data to JSON
    // URL for request POST /message
    $url = 'https://eu7.chat-api.com/instance5469/message?token=d84laii298pl228r';
    $options = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-type: application/json',
        'content' => $json1
    ]
    ]);

    // Send a request
    //$result = file_get_contents($url, false, $options);
    
    
    
    set_error_handler(
    function ($severity, $message, $file, $line) {
        throw new ErrorException($message, $severity, $severity, $file, $line);
    }
);

try {
     $result = file_get_contents($url, false, $options);
     var_dump($result);
}
catch (Exception $e) {
    echo "Error : " .$e->getMessage();
}

restore_error_handler();
    ?>